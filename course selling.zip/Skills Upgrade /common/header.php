<?php
// Set before including: $pageTitle (string), $noChrome (bool), $hideBottomNav (bool)
$S = settings();
$appName = $S['app_name'] ?: 'SkillzUp';
$me = user();
$noChrome = $noChrome ?? false;
$pageTitle = isset($pageTitle) ? $pageTitle . ' | ' . $appName : $appName;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="csrf" content="<?= e(csrf_token()) ?>">
<meta name="theme-color" content="#0284C7">
<title><?= e($pageTitle) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script>tailwind.config = { theme: { extend: { colors: { brand: '#0284C7' } } } }</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
  *{-webkit-tap-highlight-color:transparent}
  html,body{-webkit-user-select:none;-moz-user-select:none;user-select:none;-webkit-touch-callout:none;touch-action:pan-x pan-y}
  input,textarea,select{-webkit-user-select:text;user-select:text}
  img,video{-webkit-user-drag:none}
  .hide-scroll{scrollbar-width:none}
  .hide-scroll::-webkit-scrollbar{display:none}
</style>
<script>
  /* ---- AJAX + toast helpers ---- */
  const CSRF = document.querySelector('meta[name=csrf]').content;
  async function api(url, data) {
    const fd = (data instanceof FormData) ? data : new FormData();
    if (!(data instanceof FormData)) { for (const k in (data || {})) fd.append(k, data[k]); }
    fd.set('csrf', CSRF);
    try {
      const r = await fetch(url, { method: 'POST', body: fd, credentials: 'same-origin' });
      const j = await r.json();
      if (j.ok === false && j.redirect) { location.href = j.redirect; }
      return j;
    } catch (err) {
      return { ok: false, msg: 'Network or server error. Please try again.' };
    }
  }
  function toast(msg, ok) {
    let t = document.getElementById('toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'toast';
      t.className = 'fixed left-0 right-0 top-14 z-50 text-white text-center text-sm py-3 px-4';
      document.body.appendChild(t);
    }
    t.style.background = ok === false ? '#dc2626' : '#16a34a';
    t.textContent = msg;
    t.style.display = 'block';
    clearTimeout(t._h);
    t._h = setTimeout(function () { t.style.display = 'none'; }, 3000);
  }

  /* ---- Disable right-click, selection, zoom, shortcuts ---- */
  (function () {
    function isField(t) { return t && /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName); }
    document.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    ['dragstart', 'selectstart', 'copy', 'cut'].forEach(function (n) {
      document.addEventListener(n, function (e) { if (!isField(e.target)) e.preventDefault(); });
    });
    ['gesturestart', 'gesturechange', 'gestureend'].forEach(function (n) {
      document.addEventListener(n, function (e) { e.preventDefault(); });
    });
    document.addEventListener('touchmove', function (e) {
      if (e.touches.length > 1 || (e.scale && e.scale !== 1)) e.preventDefault();
    }, { passive: false });
    document.addEventListener('wheel', function (e) { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
    document.addEventListener('keydown', function (e) {
      const k = e.key.toLowerCase(), c = e.ctrlKey || e.metaKey;
      if (e.key === 'F12' ||
          (c && ['+', '-', '=', '0', 's', 'u', 'p'].indexOf(k) > -1) ||
          (c && e.shiftKey && ['i', 'j', 'c'].indexOf(k) > -1) ||
          (c && k === 'c' && !isField(e.target))) e.preventDefault();
    });
  })();
</script>
</head>
<body class="bg-gray-100 text-gray-900 <?= $noChrome ? '' : 'pt-14 pb-16' ?>">
<?php if (!$noChrome): ?>
<header class="fixed top-0 inset-x-0 h-14 bg-brand text-white grid grid-cols-3 items-center z-30">
  <button type="button" id="menuBtn" class="h-14 w-14 flex items-center justify-center text-xl" aria-label="Menu"><i class="fa-solid fa-bars"></i></button>
  <div class="text-center font-bold text-lg truncate"><?= e($appName) ?></div>
  <a href="profile.php" class="h-14 w-14 ml-auto flex items-center justify-center text-xl" aria-label="Profile"><i class="fa-solid fa-circle-user"></i></a>
</header>
<?php include __DIR__ . '/sidebar.php'; ?>
<main class="max-w-3xl mx-auto">
<?php endif; ?>
