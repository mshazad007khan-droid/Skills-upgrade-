<?php if (!($noChrome ?? false)): ?>
</main>
<?php if (!($hideBottomNav ?? false)):
    $cur = basename($_SERVER['SCRIPT_NAME']);
    $nav = [
        ['index.php', 'fa-house', 'Home'],
        ['mycourses.php', 'fa-graduation-cap', 'My Courses'],
        ['help.php', 'fa-circle-question', 'Help'],
        ['profile.php', 'fa-user', 'Profile'],
    ];
?>
<nav class="fixed bottom-0 inset-x-0 h-14 bg-brand text-white grid grid-cols-4 z-30">
  <?php foreach ($nav as $n): ?>
    <a href="<?= $n[0] ?>" class="flex flex-col items-center justify-center text-xs gap-1 <?= $cur === $n[0] ? 'bg-sky-800' : '' ?>">
      <i class="fa-solid <?= $n[1] ?> text-base"></i><span><?= $n[2] ?></span>
    </a>
  <?php endforeach; ?>
</nav>
<?php endif; ?>
<?php endif; ?>
</body>
</html>
