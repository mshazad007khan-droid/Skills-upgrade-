<?php
/* SkillzUp - shared config + helpers */
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}
date_default_timezone_set('Asia/Kolkata'); // change if needed
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', 'skillzup');
define('BASE_PATH', dirname(__DIR__));
define('UPLOAD_DIR', BASE_PATH . '/uploads');

$db = null;
if (!defined('NO_DB')) {
    try {
        $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $db->set_charset('utf8mb4');
        $db->query('SELECT 1 FROM settings LIMIT 1');
    } catch (Throwable $e) {
        http_response_code(500);
        exit('Database is not ready. Run install.php first.');
    }
}

/* ---------- database helpers (prepared statements) ---------- */
function run($sql, $types = '', $params = [])
{
    global $db;
    $st = $db->prepare($sql);
    if ($types !== '') {
        $st->bind_param($types, ...$params);
    }
    $st->execute();
    return $st;
}
function rows($sql, $types = '', $params = [])
{
    $st = run($sql, $types, $params);
    $r = $st->get_result();
    $out = $r ? $r->fetch_all(MYSQLI_ASSOC) : [];
    $st->close();
    return $out;
}
function row($sql, $types = '', $params = [])
{
    $r = rows($sql, $types, $params);
    return $r[0] ?? null;
}
function exec_sql($sql, $types = '', $params = [])
{
    $st = run($sql, $types, $params);
    $res = ['id' => $st->insert_id, 'rows' => $st->affected_rows];
    $st->close();
    return $res;
}

/* ---------- small utilities ---------- */
function e($s)
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}
function p($k)
{
    return trim((string)($_POST[$k] ?? ''));
}
function json_out($arr, $code = 200)
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($arr);
    exit;
}
// Runs an AJAX handler that returns an array; RuntimeException messages are shown to the user.
function handle(callable $fn)
{
    try {
        json_out($fn());
    } catch (RuntimeException $e) {
        json_out(['ok' => false, 'msg' => $e->getMessage()]);
    } catch (Throwable $e) {
        json_out(['ok' => false, 'msg' => 'Something went wrong. Please try again.']);
    }
}
function csrf_token()
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}
function csrf_check()
{
    $t = $_POST['csrf'] ?? '';
    if (!is_string($t) || !hash_equals($_SESSION['csrf'] ?? '', $t)) {
        json_out(['ok' => false, 'msg' => 'Session expired. Refresh the page and try again.'], 419);
    }
}

/* ---------- settings / auth ---------- */
function settings()
{
    static $s = null;
    if ($s === null) {
        $s = row('SELECT * FROM settings WHERE id=1') ?: [];
        $s += ['app_name' => 'SkillzUp', 'razorpay_key' => '', 'razorpay_secret' => '', 'support_email' => '', 'support_phone' => ''];
    }
    return $s;
}
function user()
{
    static $u = false;
    if ($u !== false) {
        return $u;
    }
    $u = null;
    if (!empty($_SESSION['uid'])) {
        $u = row('SELECT id,name,phone,email FROM users WHERE id=?', 'i', [(int)$_SESSION['uid']]);
        if (!$u) {
            unset($_SESSION['uid']);
        }
    }
    return $u;
}
function require_user()
{
    if (!user()) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            json_out(['ok' => false, 'msg' => 'Please log in again.', 'redirect' => 'login.php'], 401);
        }
        header('Location: login.php');
        exit;
    }
}
function require_admin()
{
    if (empty($_SESSION['aid']) || !row('SELECT id FROM admin WHERE id=?', 'i', [(int)$_SESSION['aid']])) {
        unset($_SESSION['aid']);
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            json_out(['ok' => false, 'msg' => 'Please log in again.', 'redirect' => 'login.php'], 401);
        }
        header('Location: login.php');
        exit;
    }
}
function owns($uid, $cid)
{
    return (bool)row("SELECT id FROM orders WHERE user_id=? AND course_id=? AND status='success' LIMIT 1", 'ii', [(int)$uid, (int)$cid]);
}

/* ---------- formatting / UI helpers ---------- */
function money($n)
{
    $n = (float)$n;
    return '₹' . number_format($n, floor($n) == $n ? 0 : 2);
}
function price_label($n)
{
    return (float)$n > 0 ? money($n) : 'Free';
}
function discount_pct($mrp, $price)
{
    $mrp = (float)$mrp;
    return $mrp > 0 && $mrp > (float)$price ? (int)round(($mrp - (float)$price) / $mrp * 100) : 0;
}
function status_badge($s)
{
    if ($s === 'success') {
        return '<span class="text-xs font-semibold px-2 py-1 bg-green-100 text-green-700">Success</span>';
    }
    if ($s === 'failed') {
        return '<span class="text-xs font-semibold px-2 py-1 bg-red-100 text-red-700">Failed</span>';
    }
    return '<span class="text-xs font-semibold px-2 py-1 bg-amber-100 text-amber-700">Pending</span>';
}
// 16:9 image box with placeholder. $prefix = '../' when used from /admin
function thumb_box($file, $dir = 'courses', $prefix = '')
{
    $h = '<div class="aspect-video bg-gray-200 overflow-hidden w-full">';
    if ($file && is_file(UPLOAD_DIR . '/' . $dir . '/' . $file)) {
        $h .= '<img src="' . $prefix . 'uploads/' . $dir . '/' . e($file) . '" alt="" draggable="false" class="w-full h-full object-cover">';
    } else {
        $h .= '<div class="w-full h-full flex items-center justify-center text-gray-400 text-3xl"><i class="fa-solid fa-image"></i></div>';
    }
    return $h . '</div>';
}
function course_card($c, $cls = '')
{
    $d = discount_pct($c['mrp'], $c['price']);
    $h = '<a href="course_detail.php?id=' . (int)$c['id'] . '" class="block bg-white ' . $cls . '">';
    $h .= thumb_box($c['image']);
    $h .= '<div class="p-2"><div class="text-sm font-semibold leading-snug line-clamp-2 h-10">' . e($c['title']) . '</div>';
    $h .= '<div class="mt-1 flex items-center gap-2 flex-wrap"><span class="font-bold text-brand">' . price_label($c['price']) . '</span>';
    if ($d > 0) {
        $h .= '<span class="text-xs text-gray-400 line-through">' . money($c['mrp']) . '</span>';
        $h .= '<span class="text-xs font-semibold text-green-600">' . $d . '% off</span>';
    }
    return $h . '</div></div></a>';
}

/* ---------- uploads / cleanup ---------- */
function upload_image($f, $dir)
{
    if (!isset($f['error']) || $f['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Image upload failed. Check the file size limit.');
    }
    if ($f['size'] > 5 * 1024 * 1024) {
        throw new RuntimeException('Image must be under 5 MB.');
    }
    $info = @getimagesize($f['tmp_name']);
    $map = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
    if (!$info || !isset($map[$info[2]])) {
        throw new RuntimeException('Only JPG, PNG or WEBP images are allowed.');
    }
    $dest = UPLOAD_DIR . '/' . $dir;
    if (!is_dir($dest)) {
        mkdir($dest, 0755, true);
    }
    $name = bin2hex(random_bytes(12)) . '.' . $map[$info[2]];
    if (!move_uploaded_file($f['tmp_name'], $dest . '/' . $name)) {
        throw new RuntimeException('Could not save the image.');
    }
    return $name;
}
function delete_file($dir, $name)
{
    if ($name) {
        $path = UPLOAD_DIR . '/' . $dir . '/' . basename($name);
        if (is_file($path)) {
            @unlink($path);
        }
    }
}
function purge_chapter($chid)
{
    foreach (rows('SELECT filename FROM videos WHERE chapter_id=?', 'i', [$chid]) as $v) {
        delete_file('videos', $v['filename']);
    }
    exec_sql('DELETE FROM videos WHERE chapter_id=?', 'i', [$chid]);
    exec_sql('DELETE FROM chapters WHERE id=?', 'i', [$chid]);
}
