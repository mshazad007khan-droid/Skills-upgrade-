<?php
$cur = basename($_SERVER['SCRIPT_NAME']);
$links = [
    ['index.php', 'fa-house', 'Home'],
    ['course.php', 'fa-layer-group', 'All Courses'],
    ['mycourses.php', 'fa-graduation-cap', 'My Courses'],
    ['help.php', 'fa-circle-question', 'Help & Support'],
    ['profile.php', 'fa-user', 'Profile'],
];
?>
<div id="overlay" class="hidden fixed inset-0 bg-black/50 z-40"></div>
<aside id="drawer" class="hidden fixed top-0 left-0 bottom-0 w-72 max-w-[80%] bg-white z-50">
  <div class="h-full flex flex-col">
    <div class="bg-brand text-white p-4 pt-6">
      <i class="fa-solid fa-circle-user text-5xl"></i>
      <div class="mt-2 font-bold truncate"><?= e($me['name'] ?? '') ?></div>
      <div class="text-sm text-sky-100 truncate"><?= e($me['email'] ?? '') ?></div>
    </div>
    <nav class="flex-1 overflow-y-auto">
      <?php foreach ($links as $l): ?>
        <a href="<?= $l[0] ?>" class="flex items-center gap-4 px-4 py-4 <?= $cur === $l[0] ? 'bg-sky-50 text-brand font-semibold' : 'text-gray-700' ?>">
          <i class="fa-solid <?= $l[1] ?> w-5 text-center"></i><?= $l[2] ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <a href="profile.php?logout=1" class="flex items-center gap-4 px-4 py-4 text-red-600 bg-gray-50">
      <i class="fa-solid fa-right-from-bracket w-5 text-center"></i>Logout
    </a>
  </div>
</aside>
<script>
  (function () {
    var d = document.getElementById('drawer'), o = document.getElementById('overlay');
    function toggle(show) { d.classList.toggle('hidden', !show); o.classList.toggle('hidden', !show); }
    document.getElementById('menuBtn').addEventListener('click', function () { toggle(true); });
    o.addEventListener('click', function () { toggle(false); });
  })();
</script>
