<?php
/* SkillzUp installer - open once in the browser, then DELETE this file. */
define('NO_DB', true);
require_once __DIR__ . '/common/config.php';

try {
    $c = new mysqli(DB_HOST, DB_USER, DB_PASS);
    $c->set_charset('utf8mb4');
    $c->query('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $c->select_db(DB_NAME);

    $opt = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $tables = [
        "CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            email VARCHAR(150) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) $opt",
        "CREATE TABLE IF NOT EXISTS admin (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL
        ) $opt",
        "CREATE TABLE IF NOT EXISTS banners (
            id INT AUTO_INCREMENT PRIMARY KEY,
            image VARCHAR(255) NOT NULL,
            link VARCHAR(255) NOT NULL DEFAULT ''
        ) $opt",
        "CREATE TABLE IF NOT EXISTS courses (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(200) NOT NULL,
            category VARCHAR(100) NOT NULL DEFAULT '',
            mrp DECIMAL(10,2) NOT NULL DEFAULT 0,
            price DECIMAL(10,2) NOT NULL DEFAULT 0,
            description TEXT,
            image VARCHAR(255) NOT NULL DEFAULT '',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) $opt",
        "CREATE TABLE IF NOT EXISTS chapters (
            id INT AUTO_INCREMENT PRIMARY KEY,
            course_id INT NOT NULL,
            title VARCHAR(200) NOT NULL,
            INDEX (course_id)
        ) $opt",
        "CREATE TABLE IF NOT EXISTS videos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            chapter_id INT NOT NULL,
            title VARCHAR(200) NOT NULL,
            filename VARCHAR(255) NOT NULL,
            INDEX (chapter_id)
        ) $opt",
        "CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            course_id INT NOT NULL,
            amount DECIMAL(10,2) NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'created',
            razorpay_order_id VARCHAR(100) NOT NULL DEFAULT '',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX (user_id, course_id),
            INDEX (razorpay_order_id)
        ) $opt",
        "CREATE TABLE IF NOT EXISTS settings (
            id INT PRIMARY KEY,
            app_name VARCHAR(100) NOT NULL DEFAULT 'SkillzUp',
            razorpay_key VARCHAR(100) NOT NULL DEFAULT '',
            razorpay_secret VARCHAR(100) NOT NULL DEFAULT '',
            support_email VARCHAR(150) NOT NULL DEFAULT '',
            support_phone VARCHAR(30) NOT NULL DEFAULT ''
        ) $opt",
    ];
    foreach ($tables as $sql) {
        $c->query($sql);
    }

    // Folders
    $deny = "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder deny,allow\nDeny from all\n</IfModule>\n";
    $noPhp = "<FilesMatch \"\\.(php|phtml|php5|phar)$\">\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder deny,allow\nDeny from all\n</IfModule>\n</FilesMatch>\n";
    foreach (['uploads', 'uploads/banners', 'uploads/courses', 'uploads/videos'] as $d) {
        if (!is_dir(BASE_PATH . '/' . $d)) {
            mkdir(BASE_PATH . '/' . $d, 0755, true);
        }
    }
    file_put_contents(BASE_PATH . '/uploads/videos/.htaccess', $deny);      // videos only via watch.php
    file_put_contents(BASE_PATH . '/uploads/banners/.htaccess', $noPhp);
    file_put_contents(BASE_PATH . '/uploads/courses/.htaccess', $noPhp);
    file_put_contents(BASE_PATH . '/uploads/videos/index.html', '');

    // Default admin + settings row (no dummy data)
    $r = $c->query('SELECT COUNT(*) n FROM admin')->fetch_assoc();
    if ((int)$r['n'] === 0) {
        $st = $c->prepare('INSERT INTO admin (username, password) VALUES (?, ?)');
        $u = 'admin';
        $h = password_hash('123456', PASSWORD_DEFAULT);
        $st->bind_param('ss', $u, $h);
        $st->execute();
    }
    $r = $c->query('SELECT COUNT(*) n FROM settings')->fetch_assoc();
    if ((int)$r['n'] === 0) {
        $c->query("INSERT INTO settings (id, app_name) VALUES (1, 'SkillzUp')");
    }

    header('Location: login.php');
    exit;
} catch (Throwable $e) {
    http_response_code(500);
    echo '<!DOCTYPE html><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:sans-serif;padding:24px">';
    echo '<h2 style="color:#dc2626">Install failed</h2><p>' . htmlspecialchars($e->getMessage()) . '</p>';
    echo '<p>Check MySQL is running and the credentials in common/config.php.</p></body>';
}
