<?php
require_once __DIR__ . '/common/config.php';
require_user();
$me = user();

/* Razorpay REST call using CURL (no vendor/composer) */
function rzp($method, $path, $key, $secret, $body = null)
{
    $ch = curl_init('https://api.razorpay.com/v1' . $path);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_USERPWD => $key . ':' . $secret,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    }
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    if ($res === false) {
        throw new RuntimeException('Could not reach Razorpay. ' . $err);
    }
    return [$code, json_decode($res, true) ?: []];
}

/* ---------- AJAX actions ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $S = settings();
    $action = p('action');

    handle(function () use ($me, $S, $action) {
        $key = $S['razorpay_key'];
        $secret = $S['razorpay_secret'];

        if ($action === 'create') {
            $cid = (int)($_POST['course_id'] ?? 0);
            $c = row('SELECT * FROM courses WHERE id=?', 'i', [$cid]);
            if (!$c) {
                throw new RuntimeException('Course not found.');
            }
            if (owns($me['id'], $cid)) {
                return ['ok' => true, 'free' => true, 'redirect' => 'mycourses.php'];
            }
            $amount = (float)$c['price'];
            if ($amount <= 0) { // free course: enroll directly
                exec_sql("INSERT INTO orders (user_id,course_id,amount,status,razorpay_order_id) VALUES (?,?,0,'success','FREE')", 'ii', [$me['id'], $cid]);
                return ['ok' => true, 'free' => true, 'redirect' => 'mycourses.php'];
            }
            if ($key === '' || $secret === '') {
                throw new RuntimeException('Payments are not set up yet. Please contact support.');
            }
            $paise = (int)round($amount * 100);
            [$code, $o] = rzp('POST', '/orders', $key, $secret, [
                'amount' => $paise,
                'currency' => 'INR',
                'receipt' => 'sk_' . $me['id'] . '_' . $cid . '_' . time(),
                'notes' => ['user_id' => (string)$me['id'], 'course_id' => (string)$cid],
            ]);
            if ($code !== 200 || empty($o['id'])) {
                throw new RuntimeException('Could not start the payment. ' . ($o['error']['description'] ?? ''));
            }
            exec_sql("INSERT INTO orders (user_id,course_id,amount,status,razorpay_order_id) VALUES (?,?,?,'created',?)", 'iids', [$me['id'], $cid, $amount, $o['id']]);
            return [
                'ok' => true,
                'key' => $key,
                'order_id' => $o['id'],
                'amount' => $paise,
                'name' => $S['app_name'],
                'title' => $c['title'],
                'prefill' => ['name' => $me['name'], 'email' => $me['email'], 'contact' => $me['phone']],
            ];
        }

        if ($action === 'verify') {
            if ($key === '' || $secret === '') {
                throw new RuntimeException('Payments are not set up.');
            }
            $oid = p('razorpay_order_id');
            $pid = p('razorpay_payment_id');
            $sig = p('razorpay_signature');
            $o = row('SELECT * FROM orders WHERE razorpay_order_id=? AND user_id=?', 'si', [$oid, $me['id']]);
            if (!$o) {
                throw new RuntimeException('Order not found.');
            }
            if ($o['status'] === 'success') {
                return ['ok' => true, 'redirect' => 'mycourses.php'];
            }
            // 1) Signature check
            $expected = hash_hmac('sha256', $oid . '|' . $pid, $secret);
            if (!hash_equals($expected, $sig)) {
                exec_sql("UPDATE orders SET status='failed' WHERE id=? AND status<>'success'", 'i', [$o['id']]);
                throw new RuntimeException('Payment verification failed. If money was deducted, contact support.');
            }
            // 2) Confirm with Razorpay API (order, amount, status)
            [$code, $pay] = rzp('GET', '/payments/' . rawurlencode($pid), $key, $secret);
            if ($code !== 200 || ($pay['order_id'] ?? '') !== $oid || (int)($pay['amount'] ?? 0) !== (int)round($o['amount'] * 100)) {
                throw new RuntimeException('Payment details do not match. Please contact support.');
            }
            if (($pay['status'] ?? '') === 'authorized') {
                [$c2] = rzp('POST', '/payments/' . rawurlencode($pid) . '/capture', $key, $secret, ['amount' => $pay['amount'], 'currency' => 'INR']);
                if ($c2 !== 200) {
                    throw new RuntimeException('Could not complete the payment. Please contact support.');
                }
                $pay['status'] = 'captured';
            }
            if (($pay['status'] ?? '') !== 'captured') {
                throw new RuntimeException('Payment is not completed.');
            }
            exec_sql("UPDATE orders SET status='success' WHERE id=?", 'i', [$o['id']]);
            return ['ok' => true, 'redirect' => 'mycourses.php'];
        }

        if ($action === 'failed') {
            exec_sql("UPDATE orders SET status='failed' WHERE razorpay_order_id=? AND user_id=? AND status='created'", 'si', [p('razorpay_order_id'), $me['id']]);
            return ['ok' => true];
        }
        throw new RuntimeException('Invalid request.');
    });
}

/* ---------- Page ---------- */
$id = (int)($_GET['id'] ?? 0);
$c = row('SELECT * FROM courses WHERE id=?', 'i', [$id]);
if (!$c) {
    header('Location: course.php');
    exit;
}
if (owns($me['id'], $id)) {
    header('Location: watch.php?id=' . $id);
    exit;
}
$d = discount_pct($c['mrp'], $c['price']);

$pageTitle = 'Checkout';
$hideBottomNav = true;
include __DIR__ . '/common/header.php';
?>
<?= thumb_box($c['image']) ?>
<div class="bg-white p-4">
  <h1 class="font-bold text-lg leading-snug"><?= e($c['title']) ?></h1>
</div>

<div class="bg-white p-4 mt-2 text-sm">
  <div class="flex justify-between py-1"><span class="text-gray-500">Course price</span><span class="<?= $d > 0 ? 'line-through text-gray-400' : '' ?>"><?= money($c['mrp']) ?></span></div>
  <?php if ($d > 0): ?>
    <div class="flex justify-between py-1"><span class="text-gray-500">Discount</span><span class="text-green-600">-<?= money($c['mrp'] - $c['price']) ?> (<?= $d ?>%)</span></div>
  <?php endif; ?>
  <div class="flex justify-between py-2 mt-1 font-bold text-base bg-gray-50 px-2"><span>Total</span><span class="text-brand"><?= price_label($c['price']) ?></span></div>
</div>

<div id="err" class="hidden mx-3 mt-3 p-3 text-sm bg-red-100 text-red-700"></div>
<div id="info" class="hidden mx-3 mt-3 p-3 text-sm bg-sky-100 text-sky-800"></div>

<a href="course_detail.php?id=<?= $id ?>" class="block text-center text-sm text-gray-500 mt-4">Back to course</a>

<button type="button" id="payBtn" class="fixed bottom-0 inset-x-0 h-14 bg-brand text-white font-bold z-30">
  <?= (float)$c['price'] > 0 ? 'Pay ' . money($c['price']) : 'Enroll for Free' ?>
</button>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
  var CID = <?= (int)$id ?>;
  var btn = document.getElementById('payBtn'), err = document.getElementById('err'), info = document.getElementById('info');
  function showErr(m) { info.classList.add('hidden'); err.textContent = m; err.classList.remove('hidden'); }
  function showInfo(m) { err.classList.add('hidden'); info.textContent = m; info.classList.remove('hidden'); }

  btn.addEventListener('click', async function () {
    btn.disabled = true;
    err.classList.add('hidden');
    var r = await api('buy.php', { action: 'create', course_id: CID });
    if (!r.ok) { showErr(r.msg || 'Could not start the payment.'); btn.disabled = false; return; }
    if (r.free) { location.href = r.redirect; return; }

    var rz = new Razorpay({
      key: r.key,
      amount: r.amount,
      currency: 'INR',
      name: r.name,
      description: r.title,
      order_id: r.order_id,
      prefill: r.prefill,
      theme: { color: '#0284C7' },
      handler: async function (resp) {
        showInfo('Verifying your payment. Please wait…');
        var v = await api('buy.php', {
          action: 'verify',
          razorpay_order_id: resp.razorpay_order_id,
          razorpay_payment_id: resp.razorpay_payment_id,
          razorpay_signature: resp.razorpay_signature
        });
        if (v.ok) { location.href = v.redirect; }
        else { showErr(v.msg || 'Payment could not be verified.'); btn.disabled = false; }
      },
      modal: { ondismiss: function () { btn.disabled = false; } }
    });
    rz.on('payment.failed', async function (resp) {
      await api('buy.php', { action: 'failed', razorpay_order_id: r.order_id });
      showErr('Payment failed: ' + ((resp.error && resp.error.description) || 'Please try again.'));
    });
    rz.open();
  });
</script>
<?php include __DIR__ . '/common/bottom.php'; ?>
