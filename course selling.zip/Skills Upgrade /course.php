<?php
require_once __DIR__ . '/common/config.php';
require_user();

$q = trim($_GET['q'] ?? '');
$cat = trim($_GET['cat'] ?? '');
$sort = $_GET['sort'] ?? 'latest';
$orders = ['latest' => 'id DESC', 'low' => 'price ASC, id DESC', 'high' => 'price DESC, id DESC'];

$where = [];
$types = '';
$args = [];
if ($q !== '') {
    $where[] = '(title LIKE ? OR description LIKE ?)';
    $like = '%' . $q . '%';
    $types .= 'ss';
    $args[] = $like;
    $args[] = $like;
}
if ($cat !== '') {
    $where[] = 'category=?';
    $types .= 's';
    $args[] = $cat;
}
$sql = 'SELECT * FROM courses' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY ' . ($orders[$sort] ?? $orders['latest']);
$courses = rows($sql, $types, $args);
$cats = rows("SELECT DISTINCT category FROM courses WHERE category<>'' ORDER BY category");

$pageTitle = 'Courses';
include __DIR__ . '/common/header.php';
?>
<form method="get" class="bg-white p-3 grid grid-cols-2 gap-2">
  <input type="search" name="q" value="<?= e($q) ?>" placeholder="Search courses" class="col-span-2 w-full bg-gray-100 p-3 text-sm outline-none">
  <select name="cat" onchange="this.form.submit()" class="bg-gray-100 p-3 text-sm outline-none">
    <option value="">All categories</option>
    <?php foreach ($cats as $c): ?>
      <option value="<?= e($c['category']) ?>" <?= $cat === $c['category'] ? 'selected' : '' ?>><?= e($c['category']) ?></option>
    <?php endforeach; ?>
  </select>
  <select name="sort" onchange="this.form.submit()" class="bg-gray-100 p-3 text-sm outline-none">
    <option value="latest" <?= $sort === 'latest' ? 'selected' : '' ?>>Latest</option>
    <option value="low" <?= $sort === 'low' ? 'selected' : '' ?>>Price: low to high</option>
    <option value="high" <?= $sort === 'high' ? 'selected' : '' ?>>Price: high to low</option>
  </select>
</form>

<?php if ($courses): ?>
  <div class="grid grid-cols-2 gap-3 p-3">
    <?php foreach ($courses as $c) { echo course_card($c); } ?>
  </div>
<?php else: ?>
  <p class="p-6 text-center text-gray-500 text-sm">No courses found. Try a different search or filter.</p>
<?php endif; ?>
<?php include __DIR__ . '/common/bottom.php'; ?>
