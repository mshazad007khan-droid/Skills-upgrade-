<?php
require_once __DIR__ . '/common/config.php';
require_user();
$me = user();

$id = (int)($_GET['id'] ?? 0);
$c = row('SELECT * FROM courses WHERE id=?', 'i', [$id]);
if (!$c) {
    header('Location: course.php');
    exit;
}
$owned = owns($me['id'], $id);
$chapters = rows('SELECT ch.title, COUNT(v.id) n FROM chapters ch LEFT JOIN videos v ON v.chapter_id=ch.id WHERE ch.course_id=? GROUP BY ch.id ORDER BY ch.id', 'i', [$id]);
$d = discount_pct($c['mrp'], $c['price']);

$pageTitle = $c['title'];
$hideBottomNav = true;
include __DIR__ . '/common/header.php';
?>
<?= thumb_box($c['image']) ?>

<div class="bg-white p-4">
  <h1 class="text-xl font-bold leading-snug"><?= e($c['title']) ?></h1>
  <?php if ($c['category'] !== ''): ?>
    <div class="text-xs text-gray-500 mt-1"><?= e($c['category']) ?></div>
  <?php endif; ?>
  <div class="mt-3 flex items-center gap-3 flex-wrap">
    <span class="text-2xl font-bold text-brand"><?= price_label($c['price']) ?></span>
    <?php if ($d > 0): ?>
      <span class="text-gray-400 line-through"><?= money($c['mrp']) ?></span>
      <span class="bg-green-600 text-white text-xs font-semibold px-2 py-1"><?= $d ?>% OFF</span>
    <?php endif; ?>
  </div>
</div>

<div class="bg-white p-4 mt-2">
  <h2 class="font-bold mb-2">About this course</h2>
  <p class="text-sm text-gray-700 leading-relaxed"><?= nl2br(e($c['description'])) ?></p>
</div>

<?php if ($chapters): ?>
<div class="bg-white p-4 mt-2">
  <h2 class="font-bold mb-2">What's inside</h2>
  <?php foreach ($chapters as $ch): ?>
    <div class="flex items-center justify-between py-2 text-sm">
      <span class="flex items-center gap-3"><i class="fa-solid fa-folder-open text-brand"></i><?= e($ch['title']) ?></span>
      <span class="text-gray-500"><?= (int)$ch['n'] ?> video<?= (int)$ch['n'] === 1 ? '' : 's' ?></span>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if ($owned): ?>
  <a href="watch.php?id=<?= $id ?>" class="fixed bottom-0 inset-x-0 h-14 bg-green-600 text-white font-bold flex items-center justify-center gap-2 z-30">
    <i class="fa-solid fa-circle-play"></i>Start Course
  </a>
<?php else: ?>
  <a href="buy.php?id=<?= $id ?>" class="fixed bottom-0 inset-x-0 h-14 bg-brand text-white font-bold flex items-center justify-center gap-2 z-30">
    <i class="fa-solid fa-cart-shopping"></i><?= (float)$c['price'] > 0 ? 'Buy Now · ' . money($c['price']) : 'Enroll for Free' ?>
  </a>
<?php endif; ?>
<?php include __DIR__ . '/common/bottom.php'; ?>
