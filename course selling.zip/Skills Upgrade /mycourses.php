<?php
require_once __DIR__ . '/common/config.php';
require_user();
$me = user();

$courses = rows("SELECT c.*, MAX(o.created_at) purchased FROM orders o JOIN courses c ON c.id=o.course_id WHERE o.user_id=? AND o.status='success' GROUP BY c.id ORDER BY purchased DESC", 'i', [$me['id']]);

$pageTitle = 'My Courses';
include __DIR__ . '/common/header.php';
?>
<?php if ($courses): ?>
  <div class="p-3 space-y-3">
    <?php foreach ($courses as $c): ?>
      <div class="bg-white">
        <?= thumb_box($c['image']) ?>
        <div class="p-3 flex items-center justify-between gap-3">
          <div class="font-semibold text-sm leading-snug line-clamp-2"><?= e($c['title']) ?></div>
          <a href="watch.php?id=<?= (int)$c['id'] ?>" class="shrink-0 bg-brand text-white text-sm font-semibold px-5 py-2">Start</a>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php else: ?>
  <div class="p-8 text-center">
    <i class="fa-solid fa-graduation-cap text-5xl text-gray-300"></i>
    <p class="mt-3 text-gray-600 text-sm">You haven't bought any course yet.</p>
    <a href="course.php" class="inline-block mt-4 bg-brand text-white font-semibold px-6 py-3 text-sm">Browse courses</a>
  </div>
<?php endif; ?>
<?php include __DIR__ . '/common/bottom.php'; ?>
