<?php
require_once __DIR__ . '/common/config.php';
require_user();

$S = settings();
$pageTitle = 'Help';
include __DIR__ . '/common/header.php';
?>
<div class="bg-white p-6 text-center">
  <i class="fa-solid fa-headset text-5xl text-brand"></i>
  <h1 class="mt-3 text-xl font-bold">How can we help?</h1>
  <p class="mt-1 text-sm text-gray-500">Reach out for payment, course access or account issues.</p>
</div>

<div class="mt-2 bg-white">
  <?php if ($S['support_email'] !== ''): ?>
    <a href="mailto:<?= e($S['support_email']) ?>" class="flex items-center gap-4 p-4">
      <i class="fa-solid fa-envelope text-brand text-xl w-6 text-center"></i>
      <div><div class="text-xs text-gray-500">Support email</div><div class="font-semibold text-sm"><?= e($S['support_email']) ?></div></div>
    </a>
  <?php endif; ?>
  <?php if ($S['support_phone'] !== ''): ?>
    <a href="tel:<?= e(preg_replace('/[^0-9+]/', '', $S['support_phone'])) ?>" class="flex items-center gap-4 p-4">
      <i class="fa-solid fa-phone text-brand text-xl w-6 text-center"></i>
      <div><div class="text-xs text-gray-500">Support phone</div><div class="font-semibold text-sm"><?= e($S['support_phone']) ?></div></div>
    </a>
  <?php endif; ?>
  <?php if ($S['support_email'] === '' && $S['support_phone'] === ''): ?>
    <p class="p-4 text-sm text-gray-500">Support contact details have not been added yet.</p>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/common/bottom.php'; ?>
