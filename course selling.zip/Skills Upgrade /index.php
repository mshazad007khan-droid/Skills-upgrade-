<?php
require_once __DIR__ . '/common/config.php';
require_user();

$banners = rows('SELECT * FROM banners ORDER BY id DESC');
$latest = rows('SELECT * FROM courses ORDER BY id DESC LIMIT 10');
$top = rows("SELECT c.*, COUNT(o.id) cnt FROM courses c LEFT JOIN orders o ON o.course_id=c.id AND o.status='success' GROUP BY c.id ORDER BY cnt DESC, c.id DESC LIMIT 6");

$pageTitle = 'Home';
include __DIR__ . '/common/header.php';
?>
<form action="course.php" method="get" class="p-3 bg-white">
  <div class="relative">
    <i class="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
    <input type="search" name="q" placeholder="Search courses" class="w-full bg-gray-100 rounded-full py-3 pl-11 pr-4 text-sm outline-none">
  </div>
</form>

<?php if ($banners): ?>
<div class="overflow-hidden bg-gray-200">
  <div id="track" class="flex" style="transition:transform .5s">
    <?php foreach ($banners as $b): $img = thumb_box($b['image'], 'banners'); ?>
      <?php if ($b['link']): ?>
        <a href="<?= e($b['link']) ?>" class="block w-full shrink-0"><?= $img ?></a>
      <?php else: ?>
        <div class="w-full shrink-0"><?= $img ?></div>
      <?php endif; ?>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<section class="mt-4">
  <h2 class="px-3 mb-2 font-bold text-lg">Latest Courses</h2>
  <?php if ($latest): ?>
    <div class="flex overflow-x-auto gap-3 px-3 hide-scroll">
      <?php foreach ($latest as $c) { echo course_card($c, 'w-56 shrink-0'); } ?>
    </div>
  <?php else: ?>
    <p class="px-3 text-sm text-gray-500">No courses yet. Check back soon.</p>
  <?php endif; ?>
</section>

<?php if ($top): ?>
<section class="mt-6 mb-4">
  <h2 class="px-3 mb-2 font-bold text-lg">Top Courses</h2>
  <div class="grid grid-cols-2 gap-3 px-3">
    <?php foreach ($top as $c) { echo course_card($c); } ?>
  </div>
</section>
<?php endif; ?>

<script>
  (function () {
    var t = document.getElementById('track');
    if (!t || t.children.length < 2) return;
    var n = t.children.length, i = 0;
    setInterval(function () {
      i = (i + 1) % n;
      t.style.transform = 'translateX(-' + (i * 100) + '%)';
    }, 3500);
  })();
</script>
<?php include __DIR__ . '/common/bottom.php'; ?>
