<?php
require_once __DIR__ . '/../common/config.php';
require_admin();

$orders = rows('SELECT o.*, u.name uname, u.email, c.title FROM orders o JOIN users u ON u.id=o.user_id JOIN courses c ON c.id=o.course_id ORDER BY o.id DESC LIMIT 500');

$pageTitle = 'Orders';
include __DIR__ . '/common/header.php';
?>
<div class="p-3"><h1 class="font-bold text-lg">Orders <span class="text-gray-400 font-normal text-sm">(<?= count($orders) ?>)</span></h1></div>

<div class="px-3 pb-3 space-y-2">
  <?php foreach ($orders as $o): ?>
    <div class="bg-white p-3">
      <div class="flex items-start justify-between gap-3">
        <div class="min-w-0">
          <div class="font-semibold text-sm truncate"><?= e($o['title']) ?></div>
          <div class="text-xs text-gray-500 truncate"><?= e($o['uname']) ?> · <?= e($o['email']) ?></div>
        </div>
        <?= status_badge($o['status']) ?>
      </div>
      <div class="mt-2 flex justify-between text-xs text-gray-500">
        <span><?= e(date('d M Y, h:i A', strtotime($o['created_at']))) ?></span>
        <span class="font-semibold text-gray-800"><?= price_label($o['amount']) ?></span>
      </div>
    </div>
  <?php endforeach; ?>
  <?php if (!$orders): ?>
    <p class="text-center text-sm text-gray-500 py-6">No orders yet.</p>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/common/bottom.php'; ?>
