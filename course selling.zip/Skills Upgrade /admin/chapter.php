<?php
require_once __DIR__ . '/../common/config.php';
require_admin();

$cid = (int)($_GET['course_id'] ?? 0);
$course = row('SELECT * FROM courses WHERE id=?', 'i', [$cid]);
if (!$course) {
    header('Location: course.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = p('action');
    handle(function () use ($action, $cid) {
        if ($action === 'save') {
            $id = (int)($_POST['id'] ?? 0);
            $title = p('title');
            if ($title === '' || mb_strlen($title) > 200) {
                throw new RuntimeException('Enter a chapter title (max 200 characters).');
            }
            if ($id) {
                if (!row('SELECT id FROM chapters WHERE id=? AND course_id=?', 'ii', [$id, $cid])) {
                    throw new RuntimeException('Chapter not found.');
                }
                exec_sql('UPDATE chapters SET title=? WHERE id=?', 'si', [$title, $id]);
            } else {
                exec_sql('INSERT INTO chapters (course_id, title) VALUES (?, ?)', 'is', [$cid, $title]);
            }
            return ['ok' => true];
        }
        if ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            if (!row('SELECT id FROM chapters WHERE id=? AND course_id=?', 'ii', [$id, $cid])) {
                throw new RuntimeException('Chapter not found.');
            }
            purge_chapter($id);
            return ['ok' => true];
        }
        throw new RuntimeException('Invalid request.');
    });
}

$chapters = rows('SELECT ch.*, (SELECT COUNT(*) FROM videos v WHERE v.chapter_id=ch.id) vn FROM chapters ch WHERE ch.course_id=? ORDER BY ch.id', 'i', [$cid]);
$pageTitle = 'Chapters';
include __DIR__ . '/common/header.php';
?>
<div class="p-3">
  <a href="course.php" class="text-sm text-brand"><i class="fa-solid fa-arrow-left mr-1"></i>All courses</a>
  <div class="mt-2 flex items-center justify-between gap-3">
    <h1 class="font-bold text-lg leading-snug"><?= e($course['title']) ?></h1>
    <button type="button" onclick="openForm()" class="shrink-0 bg-brand text-white text-sm font-semibold px-4 py-2"><i class="fa-solid fa-plus mr-1"></i>Add chapter</button>
  </div>
</div>

<form id="chf" class="hidden bg-white mx-3 mb-3 p-4 space-y-3" onsubmit="save(event)">
  <div id="formTitle" class="font-semibold">Add chapter</div>
  <input type="hidden" name="id" value="0">
  <input type="text" name="title" placeholder="Chapter title" required maxlength="200" class="w-full bg-gray-100 p-3 text-sm outline-none">
  <div class="grid grid-cols-2 gap-2">
    <button type="submit" class="bg-brand text-white py-3 font-semibold">Save chapter</button>
    <button type="button" onclick="closeForm()" class="bg-gray-200 py-3 font-semibold">Cancel</button>
  </div>
</form>

<div class="px-3 pb-3 space-y-3">
  <?php foreach ($chapters as $ch): ?>
    <div class="bg-white">
      <a href="video.php?chapter_id=<?= (int)$ch['id'] ?>" class="flex items-center justify-between gap-3 p-4">
        <div>
          <div class="font-semibold text-sm"><?= e($ch['title']) ?></div>
          <div class="text-xs text-gray-500 mt-1"><?= (int)$ch['vn'] ?> video<?= (int)$ch['vn'] === 1 ? '' : 's' ?></div>
        </div>
        <i class="fa-solid fa-chevron-right text-gray-400"></i>
      </a>
      <div class="px-4 pb-4 grid grid-cols-3 gap-2">
        <a href="video.php?chapter_id=<?= (int)$ch['id'] ?>" class="bg-brand text-white text-sm font-semibold py-2 text-center">Videos</a>
        <button type="button" class="bg-sky-100 text-brand text-sm font-semibold py-2"
                data-c="<?= e(json_encode(['id' => (int)$ch['id'], 'title' => $ch['title']])) ?>" onclick="editChapter(this)">Edit</button>
        <button type="button" class="bg-red-600 text-white text-sm font-semibold py-2" onclick="removeItem('chapter.php?course_id=<?= $cid ?>', <?= (int)$ch['id'] ?>, 'chapter and all its videos')">Delete</button>
      </div>
    </div>
  <?php endforeach; ?>
  <?php if (!$chapters): ?>
    <p class="text-center text-sm text-gray-500 py-6">No chapters yet. Add a chapter, then upload videos to it.</p>
  <?php endif; ?>
</div>

<script>
  var f = document.getElementById('chf');
  function openForm() {
    f.reset();
    f.id.value = 0;
    document.getElementById('formTitle').textContent = 'Add chapter';
    f.classList.remove('hidden');
    f.title.focus();
  }
  function closeForm() { f.classList.add('hidden'); }
  function editChapter(btn) {
    var d = JSON.parse(btn.dataset.c);
    f.reset();
    f.id.value = d.id;
    f.title.value = d.title;
    document.getElementById('formTitle').textContent = 'Edit chapter';
    f.classList.remove('hidden');
    f.title.focus();
  }
  async function save(e) {
    e.preventDefault();
    var btn = f.querySelector('button[type=submit]');
    btn.disabled = true;
    var fd = new FormData(f);
    fd.append('action', 'save');
    var r = await api('chapter.php?course_id=<?= $cid ?>', fd);
    if (r.ok) { location.reload(); }
    else { toast(r.msg || 'Could not save.', false); btn.disabled = false; }
  }
</script>
<?php include __DIR__ . '/common/bottom.php'; ?>
