<?php
require_once __DIR__ . '/../common/config.php';
require_admin();

$users = rows("SELECT u.*, (SELECT COUNT(*) FROM orders o WHERE o.user_id=u.id AND o.status='success') pc FROM users u ORDER BY u.id DESC LIMIT 500");
$byUser = [];
foreach (rows("SELECT o.user_id, o.amount, o.created_at, c.title FROM orders o JOIN courses c ON c.id=o.course_id WHERE o.status='success' ORDER BY o.id DESC") as $o) {
    $byUser[$o['user_id']][] = $o;
}

$pageTitle = 'Users';
include __DIR__ . '/common/header.php';
?>
<div class="p-3"><h1 class="font-bold text-lg">Users <span class="text-gray-400 font-normal text-sm">(<?= count($users) ?>)</span></h1></div>

<div class="px-3 pb-3 space-y-2">
  <?php foreach ($users as $u): $list = $byUser[$u['id']] ?? []; ?>
    <details class="bg-white">
      <summary class="p-3 flex items-center gap-3 cursor-pointer list-none">
        <i class="fa-solid fa-circle-user text-3xl text-gray-300"></i>
        <div class="flex-1 min-w-0">
          <div class="font-semibold text-sm truncate"><?= e($u['name']) ?></div>
          <div class="text-xs text-gray-500 truncate"><?= e($u['email']) ?></div>
          <div class="text-xs text-gray-500"><?= e($u['phone']) ?> · Joined <?= e(date('d M Y', strtotime($u['created_at']))) ?></div>
        </div>
        <span class="text-xs font-semibold bg-sky-100 text-brand px-2 py-1"><?= (int)$u['pc'] ?> purchased</span>
      </summary>
      <div class="px-3 pb-3 bg-gray-50">
        <?php if ($list): foreach ($list as $o): ?>
          <div class="flex justify-between gap-3 py-2 text-sm">
            <div class="min-w-0"><div class="truncate"><?= e($o['title']) ?></div><div class="text-xs text-gray-500"><?= e(date('d M Y, h:i A', strtotime($o['created_at']))) ?></div></div>
            <div class="font-semibold shrink-0"><?= price_label($o['amount']) ?></div>
          </div>
        <?php endforeach; else: ?>
          <p class="py-2 text-sm text-gray-500">No purchases yet.</p>
        <?php endif; ?>
      </div>
    </details>
  <?php endforeach; ?>
  <?php if (!$users): ?>
    <p class="text-center text-sm text-gray-500 py-6">No users have signed up yet.</p>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/common/bottom.php'; ?>
