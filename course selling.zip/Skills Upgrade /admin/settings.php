<?php
require_once __DIR__ . '/../common/config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = p('action');
    handle(function () use ($action) {
        if ($action === 'settings') {
            $app = p('app_name');
            $email = p('support_email');
            $phone = p('support_phone');
            $key = p('razorpay_key');
            $secret = p('razorpay_secret');
            if ($app === '' || mb_strlen($app) > 100) {
                throw new RuntimeException('Enter an app name (max 100 characters).');
            }
            if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new RuntimeException('Enter a valid email address.');
            }
            if ($phone !== '' && !preg_match('/^[0-9+\-\s()]{6,30}$/', $phone)) {
                throw new RuntimeException('Enter a valid phone number.');
            }
            $cur = settings();
            if ($secret === '') {
                $secret = $cur['razorpay_secret']; // blank = keep existing secret
            }
            exec_sql('UPDATE settings SET app_name=?, support_email=?, support_phone=?, razorpay_key=?, razorpay_secret=? WHERE id=1', 'sssss', [$app, $email, $phone, $key, $secret]);
            return ['ok' => true, 'msg' => 'Settings saved.'];
        }
        if ($action === 'password') {
            $a = row('SELECT * FROM admin WHERE id=?', 'i', [(int)$_SESSION['aid']]);
            if (!password_verify((string)($_POST['current_password'] ?? ''), $a['password'])) {
                throw new RuntimeException('Current password is incorrect.');
            }
            $new = (string)($_POST['new_password'] ?? '');
            if (strlen($new) < 6) {
                throw new RuntimeException('New password must be at least 6 characters.');
            }
            exec_sql('UPDATE admin SET password=? WHERE id=?', 'si', [password_hash($new, PASSWORD_DEFAULT), $a['id']]);
            return ['ok' => true, 'msg' => 'Password changed.'];
        }
        throw new RuntimeException('Invalid request.');
    });
}

$S = settings();
$pageTitle = 'Settings';
include __DIR__ . '/common/header.php';
?>
<div class="p-3"><h1 class="font-bold text-lg">Settings</h1></div>

<form id="sf" class="bg-white mx-3 mb-3 p-4 space-y-3" onsubmit="send(event,'settings','sf')">
  <div class="font-semibold">App</div>
  <label class="block text-xs text-gray-500">App name</label>
  <input type="text" name="app_name" value="<?= e($S['app_name']) ?>" required maxlength="100" class="w-full bg-gray-100 p-3 text-sm outline-none">
  <label class="block text-xs text-gray-500">Admin / support email</label>
  <input type="email" name="support_email" value="<?= e($S['support_email']) ?>" class="w-full bg-gray-100 p-3 text-sm outline-none">
  <label class="block text-xs text-gray-500">Admin / support phone</label>
  <input type="tel" name="support_phone" value="<?= e($S['support_phone']) ?>" class="w-full bg-gray-100 p-3 text-sm outline-none">

  <div class="font-semibold pt-2">Razorpay</div>
  <label class="block text-xs text-gray-500">Key ID</label>
  <input type="text" name="razorpay_key" value="<?= e($S['razorpay_key']) ?>" autocomplete="off" class="w-full bg-gray-100 p-3 text-sm outline-none">
  <label class="block text-xs text-gray-500">Key Secret</label>
  <input type="password" name="razorpay_secret" value="" autocomplete="new-password"
         placeholder="<?= $S['razorpay_secret'] !== '' ? 'Saved. Leave blank to keep it' : 'Enter key secret' ?>" class="w-full bg-gray-100 p-3 text-sm outline-none">

  <button type="submit" class="w-full bg-brand text-white py-3 font-semibold">Save settings</button>
</form>

<form id="pf" class="bg-white mx-3 mb-3 p-4 space-y-3" onsubmit="send(event,'password','pf')">
  <div class="font-semibold">Change admin password</div>
  <input type="password" name="current_password" placeholder="Current password" required autocomplete="current-password" class="w-full bg-gray-100 p-3 text-sm outline-none">
  <input type="password" name="new_password" placeholder="New password (min 6 characters)" required minlength="6" autocomplete="new-password" class="w-full bg-gray-100 p-3 text-sm outline-none">
  <button type="submit" class="w-full bg-brand text-white py-3 font-semibold">Change password</button>
</form>

<script>
  async function send(e, action, id) {
    e.preventDefault();
    var f = document.getElementById(id), btn = f.querySelector('button[type=submit]');
    btn.disabled = true;
    var fd = new FormData(f);
    fd.append('action', action);
    var r = await api('settings.php', fd);
    btn.disabled = false;
    if (r.ok) {
      toast(r.msg);
      if (action === 'password') f.reset();
      if (action === 'settings') { f.razorpay_secret.value = ''; f.razorpay_secret.placeholder = 'Saved. Leave blank to keep it'; }
    } else {
      toast(r.msg || 'Could not save.', false);
    }
  }
</script>
<?php include __DIR__ . '/common/bottom.php'; ?>
