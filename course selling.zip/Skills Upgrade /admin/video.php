<?php
require_once __DIR__ . '/../common/config.php';
require_admin();

$chid = (int)($_GET['chapter_id'] ?? 0);
$chapter = row('SELECT * FROM chapters WHERE id=?', 'i', [$chid]);
if (!$chapter) {
    header('Location: course.php');
    exit;
}
$course = row('SELECT * FROM courses WHERE id=?', 'i', [$chapter['course_id']]);

function upload_error_text($code)
{
    switch ($code) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            return 'File is larger than the server limit. Increase upload_max_filesize and post_max_size in php.ini.';
        case UPLOAD_ERR_PARTIAL:
            return 'Upload was interrupted. Please try again.';
        case UPLOAD_ERR_NO_FILE:
            return 'Choose an MP4 video.';
        default:
            return 'Upload failed. Check folder permissions for uploads/videos.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // File bigger than post_max_size: PHP drops $_POST and $_FILES completely
    if (empty($_POST) && empty($_FILES) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
        json_out(['ok' => false, 'msg' => 'File is larger than the server limit. Increase upload_max_filesize and post_max_size in php.ini.']);
    }
    csrf_check();
    $action = p('action');
    handle(function () use ($action, $chid) {
        if ($action === 'upload') {
            $f = $_FILES['video'] ?? null;
            if (!$f || $f['error'] !== UPLOAD_ERR_OK) {
                throw new RuntimeException(upload_error_text($f['error'] ?? UPLOAD_ERR_NO_FILE));
            }
            if (strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)) !== 'mp4') {
                throw new RuntimeException('Only MP4 files are allowed.');
            }
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
            if ($mime !== 'video/mp4') {
                throw new RuntimeException('This file is not a valid MP4 video.');
            }
            $title = p('title');
            if ($title === '') {
                $title = pathinfo($f['name'], PATHINFO_FILENAME);
            }
            $title = mb_substr($title, 0, 200);
            $dir = UPLOAD_DIR . '/videos';
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            $name = bin2hex(random_bytes(16)) . '.mp4';
            if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
                throw new RuntimeException('Could not save the video. Check folder permissions.');
            }
            exec_sql('INSERT INTO videos (chapter_id, title, filename) VALUES (?,?,?)', 'iss', [$chid, $title, $name]);
            return ['ok' => true];
        }
        if ($action === 'delete') {
            $v = row('SELECT * FROM videos WHERE id=? AND chapter_id=?', 'ii', [(int)($_POST['id'] ?? 0), $chid]);
            if (!$v) {
                throw new RuntimeException('Video not found.');
            }
            delete_file('videos', $v['filename']);
            exec_sql('DELETE FROM videos WHERE id=?', 'i', [$v['id']]);
            return ['ok' => true];
        }
        throw new RuntimeException('Invalid request.');
    });
}

$videos = rows('SELECT * FROM videos WHERE chapter_id=? ORDER BY id', 'i', [$chid]);
$pageTitle = 'Videos';
include __DIR__ . '/common/header.php';
?>
<div class="p-3">
  <a href="chapter.php?course_id=<?= (int)$chapter['course_id'] ?>" class="text-sm text-brand"><i class="fa-solid fa-arrow-left mr-1"></i>Chapters</a>
  <h1 class="mt-2 font-bold text-lg leading-snug"><?= e($chapter['title']) ?></h1>
  <div class="text-xs text-gray-500"><?= e($course['title'] ?? '') ?></div>
</div>

<form id="vf" class="bg-white mx-3 mb-3 p-4 space-y-3" onsubmit="upload(event)">
  <div class="font-semibold">Upload video</div>
  <input type="text" name="title" placeholder="Video title" maxlength="200" class="w-full bg-gray-100 p-3 text-sm outline-none">
  <input type="file" name="video" accept="video/mp4,.mp4" required class="w-full text-sm">
  <div id="pwrap" class="hidden">
    <div class="h-3 bg-gray-200"><div id="pbar" class="h-3 bg-brand" style="width:0%"></div></div>
    <div id="ptxt" class="text-xs text-gray-500 mt-1">0%</div>
  </div>
  <button type="submit" id="ubtn" class="w-full bg-brand text-white py-3 font-semibold"><i class="fa-solid fa-cloud-arrow-up mr-2"></i>Upload</button>
  <p class="text-xs text-gray-500">MP4 only. Large files need higher upload_max_filesize and post_max_size in php.ini.</p>
</form>

<div class="px-3 pb-3 space-y-2">
  <?php foreach ($videos as $v):
      $p = UPLOAD_DIR . '/videos/' . basename($v['filename']);
      $mb = is_file($p) ? number_format(filesize($p) / 1048576, 1) . ' MB' : 'File missing';
  ?>
    <div class="bg-white p-3 flex items-center gap-3">
      <i class="fa-solid fa-film text-brand text-xl"></i>
      <div class="flex-1 min-w-0">
        <div class="text-sm font-semibold truncate"><?= e($v['title']) ?></div>
        <div class="text-xs text-gray-500"><?= $mb ?></div>
      </div>
      <button type="button" class="bg-red-600 text-white text-sm font-semibold px-4 py-2" onclick="removeItem('video.php?chapter_id=<?= $chid ?>', <?= (int)$v['id'] ?>, 'video')">Delete</button>
    </div>
  <?php endforeach; ?>
  <?php if (!$videos): ?>
    <p class="text-center text-sm text-gray-500 py-6">No videos in this chapter yet.</p>
  <?php endif; ?>
</div>

<script>
  function upload(e) {
    e.preventDefault();
    var f = e.target, file = f.video.files[0];
    if (!file) { toast('Choose an MP4 video.', false); return; }
    if (!/\.mp4$/i.test(file.name)) { toast('Only MP4 files are allowed.', false); return; }
    var fd = new FormData(f);
    fd.append('action', 'upload');
    fd.append('csrf', CSRF);
    var btn = document.getElementById('ubtn'), wrap = document.getElementById('pwrap'),
        bar = document.getElementById('pbar'), txt = document.getElementById('ptxt');
    btn.disabled = true;
    wrap.classList.remove('hidden');
    var x = new XMLHttpRequest();
    x.open('POST', 'video.php?chapter_id=<?= $chid ?>');
    x.upload.onprogress = function (ev) {
      if (!ev.lengthComputable) return;
      var pct = Math.round((ev.loaded / ev.total) * 100);
      bar.style.width = pct + '%';
      txt.textContent = pct < 100 ? pct + '% uploaded' : 'Processing…';
    };
    x.onload = function () {
      var r;
      try { r = JSON.parse(x.responseText); }
      catch (err) { r = { ok: false, msg: 'Upload failed. Check upload_max_filesize and post_max_size in php.ini.' }; }
      if (r.ok) { location.reload(); }
      else { toast(r.msg || 'Upload failed.', false); btn.disabled = false; wrap.classList.add('hidden'); bar.style.width = '0%'; }
    };
    x.onerror = function () {
      toast('Network error during upload.', false);
      btn.disabled = false;
      wrap.classList.add('hidden');
    };
    x.send(fd);
  }
</script>
<?php include __DIR__ . '/common/bottom.php'; ?>
