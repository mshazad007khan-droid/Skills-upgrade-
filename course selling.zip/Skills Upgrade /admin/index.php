<?php
require_once __DIR__ . '/../common/config.php';
require_admin();

$users = (int)row('SELECT COUNT(*) c FROM users')['c'];
$revenue = row("SELECT COALESCE(SUM(amount),0) s FROM orders WHERE status='success'")['s'];
$courses = (int)row('SELECT COUNT(*) c FROM courses')['c'];
$purchases = (int)row("SELECT COUNT(*) c FROM orders WHERE status='success'")['c'];

$stats = [
    ['Total Users', 'fa-users', $users, 'users.php'],
    ['Revenue', 'fa-indian-rupee-sign', money($revenue), 'payments.php'],
    ['Active Courses', 'fa-book-open', $courses, 'course.php'],
    ['Purchases', 'fa-cart-shopping', $purchases, 'orders.php'],
];

$pageTitle = 'Dashboard';
include __DIR__ . '/common/header.php';
?>
<div class="grid grid-cols-2 gap-3 p-3">
  <?php foreach ($stats as $s): ?>
    <a href="<?= $s[3] ?>" class="bg-white p-4 block">
      <i class="fa-solid <?= $s[1] ?> text-brand text-xl"></i>
      <div class="mt-3 text-2xl font-bold"><?= e($s[2]) ?></div>
      <div class="text-xs text-gray-500 mt-1"><?= $s[0] ?></div>
    </a>
  <?php endforeach; ?>
</div>

<div class="grid grid-cols-2 gap-3 px-3">
  <a href="course.php?add=1" class="bg-brand text-white text-center font-semibold py-4"><i class="fa-solid fa-plus mr-2"></i>Add Course</a>
  <a href="banner.php?add=1" class="bg-brand text-white text-center font-semibold py-4"><i class="fa-solid fa-plus mr-2"></i>Add Banner</a>
</div>
<?php include __DIR__ . '/common/bottom.php'; ?>
