<?php
require_once __DIR__ . '/../common/config.php';
require_admin();

$pays = rows("SELECT o.*, u.name uname, u.email FROM orders o JOIN users u ON u.id=o.user_id WHERE o.status IN ('success','failed') AND o.razorpay_order_id<>'FREE' ORDER BY o.id DESC LIMIT 500");
$total = row("SELECT COALESCE(SUM(amount),0) s FROM orders WHERE status='success'")['s'];

$pageTitle = 'Payments';
include __DIR__ . '/common/header.php';
?>
<div class="p-3 flex items-center justify-between">
  <h1 class="font-bold text-lg">Payments</h1>
  <div class="text-right">
    <div class="text-xs text-gray-500">Collected</div>
    <div class="font-bold text-brand"><?= money($total) ?></div>
  </div>
</div>

<div class="px-3 pb-3 space-y-2">
  <?php foreach ($pays as $o): ?>
    <div class="bg-white p-3">
      <div class="flex items-start justify-between gap-3">
        <div class="min-w-0">
          <div class="font-bold text-base"><?= money($o['amount']) ?></div>
          <div class="text-xs text-gray-500 truncate"><?= e($o['uname']) ?> · <?= e($o['email']) ?></div>
        </div>
        <?= status_badge($o['status']) ?>
      </div>
      <div class="mt-2 text-xs text-gray-500 break-all">Order ID: <?= e($o['razorpay_order_id']) ?></div>
      <div class="text-xs text-gray-500"><?= e(date('d M Y, h:i A', strtotime($o['created_at']))) ?></div>
    </div>
  <?php endforeach; ?>
  <?php if (!$pays): ?>
    <p class="text-center text-sm text-gray-500 py-6">No payments yet.</p>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/common/bottom.php'; ?>
