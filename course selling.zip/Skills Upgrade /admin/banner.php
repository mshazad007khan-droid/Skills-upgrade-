<?php
require_once __DIR__ . '/../common/config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = p('action');
    handle(function () use ($action) {
        if ($action === 'save') {
            $id = (int)($_POST['id'] ?? 0);
            $link = p('link');
            if ($link !== '' && !preg_match('~^https?://~i', $link) && !preg_match('~^[\w\-./?=&]+$~', $link)) {
                throw new RuntimeException('Enter a valid link (https://… or a page like course_detail.php?id=1).');
            }
            $has = isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE;
            if ($id) {
                $b = row('SELECT * FROM banners WHERE id=?', 'i', [$id]);
                if (!$b) {
                    throw new RuntimeException('Banner not found.');
                }
                $img = $b['image'];
                if ($has) {
                    $img = upload_image($_FILES['image'], 'banners');
                    delete_file('banners', $b['image']);
                }
                exec_sql('UPDATE banners SET image=?, link=? WHERE id=?', 'ssi', [$img, $link, $id]);
            } else {
                if (!$has) {
                    throw new RuntimeException('Choose a banner image.');
                }
                $img = upload_image($_FILES['image'], 'banners');
                exec_sql('INSERT INTO banners (image, link) VALUES (?, ?)', 'ss', [$img, $link]);
            }
            return ['ok' => true];
        }
        if ($action === 'delete') {
            $b = row('SELECT * FROM banners WHERE id=?', 'i', [(int)($_POST['id'] ?? 0)]);
            if (!$b) {
                throw new RuntimeException('Banner not found.');
            }
            delete_file('banners', $b['image']);
            exec_sql('DELETE FROM banners WHERE id=?', 'i', [$b['id']]);
            return ['ok' => true];
        }
        throw new RuntimeException('Invalid request.');
    });
}

$banners = rows('SELECT * FROM banners ORDER BY id DESC');
$pageTitle = 'Banners';
include __DIR__ . '/common/header.php';
?>
<div class="p-3 flex items-center justify-between">
  <h1 class="font-bold text-lg">Banners</h1>
  <button type="button" onclick="openForm()" class="bg-brand text-white text-sm font-semibold px-4 py-2"><i class="fa-solid fa-plus mr-1"></i>Add banner</button>
</div>

<form id="bf" class="<?= isset($_GET['add']) ? '' : 'hidden' ?> bg-white mx-3 mb-3 p-4 space-y-3" onsubmit="save(event)">
  <div id="formTitle" class="font-semibold">Add banner</div>
  <input type="hidden" name="id" value="0">
  <div class="aspect-video bg-gray-200 overflow-hidden flex items-center justify-center text-gray-400">
    <img id="pv" src="" alt="" class="hidden w-full h-full object-cover">
  </div>
  <input type="file" name="image" accept="image/jpeg,image/png,image/webp" onchange="previewImg(this,'pv')" class="w-full text-sm">
  <p class="text-xs text-gray-500">Use a 16:9 image (for example 1280×720).</p>
  <input type="text" name="link" placeholder="Link (optional)" class="w-full bg-gray-100 p-3 text-sm outline-none">
  <div class="grid grid-cols-2 gap-2">
    <button type="submit" class="bg-brand text-white py-3 font-semibold">Save banner</button>
    <button type="button" onclick="closeForm()" class="bg-gray-200 py-3 font-semibold">Cancel</button>
  </div>
</form>

<div class="px-3 pb-3 space-y-3">
  <?php foreach ($banners as $b): ?>
    <div class="bg-white">
      <?= thumb_box($b['image'], 'banners', '../') ?>
      <div class="p-3 flex items-center justify-between gap-2">
        <div class="text-xs text-gray-500 truncate flex-1"><?= $b['link'] !== '' ? e($b['link']) : 'No link' ?></div>
        <button type="button" class="bg-sky-100 text-brand text-sm font-semibold px-4 py-2"
                data-b="<?= e(json_encode(['id' => (int)$b['id'], 'link' => $b['link'], 'img' => '../uploads/banners/' . $b['image']])) ?>"
                onclick="editBanner(this)">Edit</button>
        <button type="button" class="bg-red-600 text-white text-sm font-semibold px-4 py-2" onclick="removeItem('banner.php', <?= (int)$b['id'] ?>, 'banner')">Delete</button>
      </div>
    </div>
  <?php endforeach; ?>
  <?php if (!$banners): ?>
    <p class="text-center text-sm text-gray-500 py-6">No banners yet. Add one to show it on the home slider.</p>
  <?php endif; ?>
</div>

<script>
  var f = document.getElementById('bf'), pv = document.getElementById('pv');
  function openForm() {
    f.reset();
    f.id.value = 0;
    pv.classList.add('hidden');
    pv.src = '';
    document.getElementById('formTitle').textContent = 'Add banner';
    f.classList.remove('hidden');
    f.scrollIntoView();
  }
  function closeForm() { f.classList.add('hidden'); }
  function editBanner(btn) {
    var d = JSON.parse(btn.dataset.b);
    f.reset();
    f.id.value = d.id;
    f.link.value = d.link;
    pv.src = d.img;
    pv.classList.remove('hidden');
    document.getElementById('formTitle').textContent = 'Edit banner';
    f.classList.remove('hidden');
    f.scrollIntoView();
  }
  async function save(e) {
    e.preventDefault();
    var btn = f.querySelector('button[type=submit]');
    btn.disabled = true;
    var fd = new FormData(f);
    fd.append('action', 'save');
    var r = await api('banner.php', fd);
    if (r.ok) { location.href = 'banner.php'; }
    else { toast(r.msg || 'Could not save.', false); btn.disabled = false; }
  }
</script>
<?php include __DIR__ . '/common/bottom.php'; ?>
