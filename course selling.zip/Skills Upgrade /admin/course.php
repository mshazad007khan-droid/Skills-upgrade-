<?php
require_once __DIR__ . '/../common/config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = p('action');
    handle(function () use ($action) {
        if ($action === 'save') {
            $id = (int)($_POST['id'] ?? 0);
            $title = p('title');
            $cat = p('category');
            $mrp = (float)p('mrp');
            $price = (float)p('price');
            $desc = p('description');
            if ($title === '' || mb_strlen($title) > 200) {
                throw new RuntimeException('Enter a course title (max 200 characters).');
            }
            if ($mrp < 0 || $price < 0) {
                throw new RuntimeException('MRP and price cannot be negative.');
            }
            if ($price > $mrp) {
                throw new RuntimeException('Price cannot be higher than MRP.');
            }
            $has = isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE;
            if ($id) {
                $c = row('SELECT * FROM courses WHERE id=?', 'i', [$id]);
                if (!$c) {
                    throw new RuntimeException('Course not found.');
                }
                $img = $c['image'];
                if ($has) {
                    $img = upload_image($_FILES['image'], 'courses');
                    delete_file('courses', $c['image']);
                }
                exec_sql('UPDATE courses SET title=?, category=?, mrp=?, price=?, description=?, image=? WHERE id=?', 'ssddssi', [$title, $cat, $mrp, $price, $desc, $img, $id]);
            } else {
                if (!$has) {
                    throw new RuntimeException('Choose a thumbnail image.');
                }
                $img = upload_image($_FILES['image'], 'courses');
                exec_sql('INSERT INTO courses (title, category, mrp, price, description, image) VALUES (?,?,?,?,?,?)', 'ssddss', [$title, $cat, $mrp, $price, $desc, $img]);
            }
            return ['ok' => true];
        }
        if ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            $c = row('SELECT * FROM courses WHERE id=?', 'i', [$id]);
            if (!$c) {
                throw new RuntimeException('Course not found.');
            }
            if (row('SELECT id FROM orders WHERE course_id=? LIMIT 1', 'i', [$id])) {
                throw new RuntimeException('This course has orders and cannot be deleted.');
            }
            foreach (rows('SELECT id FROM chapters WHERE course_id=?', 'i', [$id]) as $ch) {
                purge_chapter((int)$ch['id']);
            }
            delete_file('courses', $c['image']);
            exec_sql('DELETE FROM courses WHERE id=?', 'i', [$id]);
            return ['ok' => true];
        }
        throw new RuntimeException('Invalid request.');
    });
}

$courses = rows('SELECT c.*, (SELECT COUNT(*) FROM chapters ch WHERE ch.course_id=c.id) chn FROM courses c ORDER BY c.id DESC');
$pageTitle = 'Courses';
include __DIR__ . '/common/header.php';
?>
<div class="p-3 flex items-center justify-between">
  <h1 class="font-bold text-lg">Courses</h1>
  <button type="button" onclick="openForm()" class="bg-brand text-white text-sm font-semibold px-4 py-2"><i class="fa-solid fa-plus mr-1"></i>Add course</button>
</div>

<form id="cf" class="<?= isset($_GET['add']) ? '' : 'hidden' ?> bg-white mx-3 mb-3 p-4 space-y-3" onsubmit="save(event)">
  <div id="formTitle" class="font-semibold">Add course</div>
  <input type="hidden" name="id" value="0">
  <input type="text" name="title" placeholder="Course title" required maxlength="200" class="w-full bg-gray-100 p-3 text-sm outline-none">
  <input type="text" name="category" placeholder="Category (for example Design)" maxlength="100" class="w-full bg-gray-100 p-3 text-sm outline-none">
  <div class="grid grid-cols-2 gap-2">
    <input type="number" name="mrp" placeholder="MRP (₹)" min="0" step="0.01" required class="w-full bg-gray-100 p-3 text-sm outline-none">
    <input type="number" name="price" placeholder="Price (₹)" min="0" step="0.01" required class="w-full bg-gray-100 p-3 text-sm outline-none">
  </div>
  <textarea name="description" rows="5" placeholder="Description" class="w-full bg-gray-100 p-3 text-sm outline-none"></textarea>
  <div class="aspect-video bg-gray-200 overflow-hidden flex items-center justify-center text-gray-400">
    <img id="pv" src="" alt="" class="hidden w-full h-full object-cover">
  </div>
  <input type="file" name="image" accept="image/jpeg,image/png,image/webp" onchange="previewImg(this,'pv')" class="w-full text-sm">
  <p class="text-xs text-gray-500">Thumbnail: 16:9 image. Set price to 0 for a free course.</p>
  <div class="grid grid-cols-2 gap-2">
    <button type="submit" class="bg-brand text-white py-3 font-semibold">Save course</button>
    <button type="button" onclick="closeForm()" class="bg-gray-200 py-3 font-semibold">Cancel</button>
  </div>
</form>

<div class="px-3 pb-3 space-y-3">
  <?php foreach ($courses as $c): ?>
    <div class="bg-white">
      <a href="chapter.php?course_id=<?= (int)$c['id'] ?>" class="block">
        <?= thumb_box($c['image'], 'courses', '../') ?>
        <div class="p-3">
          <div class="font-semibold text-sm leading-snug"><?= e($c['title']) ?></div>
          <div class="mt-1 flex items-center gap-2 text-sm">
            <span class="font-bold text-brand"><?= price_label($c['price']) ?></span>
            <?php if (discount_pct($c['mrp'], $c['price']) > 0): ?>
              <span class="text-xs text-gray-400 line-through"><?= money($c['mrp']) ?></span>
            <?php endif; ?>
            <span class="text-xs text-gray-500 ml-auto"><?= (int)$c['chn'] ?> chapter<?= (int)$c['chn'] === 1 ? '' : 's' ?></span>
          </div>
        </div>
      </a>
      <div class="px-3 pb-3 grid grid-cols-3 gap-2">
        <a href="chapter.php?course_id=<?= (int)$c['id'] ?>" class="bg-brand text-white text-sm font-semibold py-2 text-center">Manage</a>
        <button type="button" class="bg-sky-100 text-brand text-sm font-semibold py-2"
                data-c="<?= e(json_encode(['id' => (int)$c['id'], 'title' => $c['title'], 'category' => $c['category'], 'mrp' => $c['mrp'], 'price' => $c['price'], 'description' => $c['description'], 'img' => $c['image'] ? '../uploads/courses/' . $c['image'] : ''])) ?>"
                onclick="editCourse(this)">Edit</button>
        <button type="button" class="bg-red-600 text-white text-sm font-semibold py-2" onclick="removeItem('course.php', <?= (int)$c['id'] ?>, 'course')">Delete</button>
      </div>
    </div>
  <?php endforeach; ?>
  <?php if (!$courses): ?>
    <p class="text-center text-sm text-gray-500 py-6">No courses yet. Add your first course.</p>
  <?php endif; ?>
</div>

<script>
  var f = document.getElementById('cf'), pv = document.getElementById('pv');
  function openForm() {
    f.reset();
    f.id.value = 0;
    pv.classList.add('hidden');
    pv.src = '';
    document.getElementById('formTitle').textContent = 'Add course';
    f.classList.remove('hidden');
    f.scrollIntoView();
  }
  function closeForm() { f.classList.add('hidden'); }
  function editCourse(btn) {
    var d = JSON.parse(btn.dataset.c);
    f.reset();
    f.id.value = d.id;
    f.title.value = d.title;
    f.category.value = d.category;
    f.mrp.value = d.mrp;
    f.price.value = d.price;
    f.description.value = d.description;
    if (d.img) { pv.src = d.img; pv.classList.remove('hidden'); } else { pv.classList.add('hidden'); }
    document.getElementById('formTitle').textContent = 'Edit course';
    f.classList.remove('hidden');
    f.scrollIntoView();
  }
  async function save(e) {
    e.preventDefault();
    var btn = f.querySelector('button[type=submit]');
    btn.disabled = true;
    var fd = new FormData(f);
    fd.append('action', 'save');
    var r = await api('course.php', fd);
    if (r.ok) { location.href = 'course.php'; }
    else { toast(r.msg || 'Could not save.', false); btn.disabled = false; }
  }
</script>
<?php include __DIR__ . '/common/bottom.php'; ?>
