<?php
$cur = basename($_SERVER['SCRIPT_NAME']);
$links = [
    ['index.php', 'fa-gauge', 'Dashboard'],
    ['banner.php', 'fa-image', 'Banners'],
    ['course.php', 'fa-book-open', 'Courses'],
    ['users.php', 'fa-users', 'Users'],
    ['orders.php', 'fa-cart-shopping', 'Orders'],
    ['payments.php', 'fa-indian-rupee-sign', 'Payments'],
    ['settings.php', 'fa-gear', 'Settings'],
];
// chapter.php and video.php belong to Courses
$active = in_array($cur, ['chapter.php', 'video.php'], true) ? 'course.php' : $cur;
?>
<div id="overlay" class="hidden fixed inset-0 bg-black/50 z-40"></div>
<aside id="drawer" class="hidden fixed top-0 left-0 bottom-0 w-72 max-w-[80%] bg-white z-50">
  <div class="h-full flex flex-col">
    <div class="bg-brand text-white p-4 pt-6">
      <i class="fa-solid fa-user-shield text-4xl"></i>
      <div class="mt-2 font-bold"><?= e($appName) ?></div>
      <div class="text-sm text-sky-100">Admin panel</div>
    </div>
    <nav class="flex-1 overflow-y-auto">
      <?php foreach ($links as $l): ?>
        <a href="<?= $l[0] ?>" class="flex items-center gap-4 px-4 py-4 <?= $active === $l[0] ? 'bg-sky-50 text-brand font-semibold' : 'text-gray-700' ?>">
          <i class="fa-solid <?= $l[1] ?> w-5 text-center"></i><?= $l[2] ?>
        </a>
      <?php endforeach; ?>
      <a href="../index.php" class="flex items-center gap-4 px-4 py-4 text-gray-700">
        <i class="fa-solid fa-arrow-up-right-from-square w-5 text-center"></i>View app
      </a>
    </nav>
    <a href="login.php?logout=1" class="flex items-center gap-4 px-4 py-4 text-red-600 bg-gray-50">
      <i class="fa-solid fa-right-from-bracket w-5 text-center"></i>Logout
    </a>
  </div>
</aside>
<script>
  (function () {
    var d = document.getElementById('drawer'), o = document.getElementById('overlay');
    function toggle(show) { d.classList.toggle('hidden', !show); o.classList.toggle('hidden', !show); }
    document.getElementById('menuBtn').addEventListener('click', function () { toggle(true); });
    o.addEventListener('click', function () { toggle(false); });
  })();
</script>
