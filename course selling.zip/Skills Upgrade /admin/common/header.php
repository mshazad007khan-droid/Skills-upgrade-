<?php
// Set before including: $pageTitle (string), $noChrome (bool)
$S = settings();
$appName = $S['app_name'] ?: 'SkillzUp';
$noChrome = $noChrome ?? false;
$pageTitle = isset($pageTitle) ? $pageTitle . ' | Admin' : 'Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="csrf" content="<?= e(csrf_token()) ?>">
<meta name="theme-color" content="#0284C7">
<title><?= e($pageTitle) ?></title>
<script src="https://cdn.tailwindcss.com"></script>
<script>tailwind.config = { theme: { extend: { colors: { brand: '#0284C7' } } } }</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
  *{-webkit-tap-highlight-color:transparent}
  .hide-scroll{scrollbar-width:none}
  .hide-scroll::-webkit-scrollbar{display:none}
</style>
<script>
  const CSRF = document.querySelector('meta[name=csrf]').content;
  async function api(url, data) {
    const fd = (data instanceof FormData) ? data : new FormData();
    if (!(data instanceof FormData)) { for (const k in (data || {})) fd.append(k, data[k]); }
    fd.set('csrf', CSRF);
    try {
      const r = await fetch(url, { method: 'POST', body: fd, credentials: 'same-origin' });
      const j = await r.json();
      if (j.ok === false && j.redirect) { location.href = j.redirect; }
      return j;
    } catch (err) {
      return { ok: false, msg: 'Network or server error. Please try again.' };
    }
  }
  function toast(msg, ok) {
    let t = document.getElementById('toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'toast';
      t.className = 'fixed left-0 right-0 top-14 z-50 text-white text-center text-sm py-3 px-4';
      document.body.appendChild(t);
    }
    t.style.background = ok === false ? '#dc2626' : '#16a34a';
    t.textContent = msg;
    t.style.display = 'block';
    clearTimeout(t._h);
    t._h = setTimeout(function () { t.style.display = 'none'; }, 3000);
  }
  // Confirm, then post a delete action and reload the page
  async function removeItem(url, id, what) {
    if (!confirm('Delete this ' + what + '? This cannot be undone.')) return;
    const r = await api(url, { action: 'delete', id: id });
    if (r.ok) { location.reload(); } else { toast(r.msg || 'Could not delete.', false); }
  }
  // Show a local preview for a chosen image file
  function previewImg(input, imgId) {
    const f = input.files && input.files[0];
    if (!f) return;
    const el = document.getElementById(imgId);
    el.src = URL.createObjectURL(f);
    el.classList.remove('hidden');
  }
</script>
</head>
<body class="bg-gray-100 text-gray-900 <?= $noChrome ? '' : 'pt-14 pb-16' ?>">
<?php if (!$noChrome): ?>
<header class="fixed top-0 inset-x-0 h-14 bg-brand text-white grid grid-cols-3 items-center z-30">
  <button type="button" id="menuBtn" class="h-14 w-14 flex items-center justify-center text-xl" aria-label="Menu"><i class="fa-solid fa-bars"></i></button>
  <div class="text-center font-bold truncate"><?= e($appName) ?> Admin</div>
  <a href="login.php?logout=1" class="h-14 w-14 ml-auto flex items-center justify-center text-xl" aria-label="Logout"><i class="fa-solid fa-right-from-bracket"></i></a>
</header>
<?php include __DIR__ . '/sidebar.php'; ?>
<main class="max-w-4xl mx-auto">
<?php endif; ?>
