<?php if (!($noChrome ?? false)):
    $cur = basename($_SERVER['SCRIPT_NAME']);
    $active = in_array($cur, ['chapter.php', 'video.php'], true) ? 'course.php' : $cur;
    $nav = [
        ['index.php', 'fa-gauge', 'Home'],
        ['course.php', 'fa-book-open', 'Courses'],
        ['orders.php', 'fa-cart-shopping', 'Orders'],
        ['settings.php', 'fa-gear', 'Settings'],
    ];
?>
</main>
<nav class="fixed bottom-0 inset-x-0 h-14 bg-brand text-white grid grid-cols-4 z-30">
  <?php foreach ($nav as $n): ?>
    <a href="<?= $n[0] ?>" class="flex flex-col items-center justify-center text-xs gap-1 <?= $active === $n[0] ? 'bg-sky-800' : '' ?>">
      <i class="fa-solid <?= $n[1] ?> text-base"></i><span><?= $n[2] ?></span>
    </a>
  <?php endforeach; ?>
</nav>
<?php endif; ?>
</body>
</html>
