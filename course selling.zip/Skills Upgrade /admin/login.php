<?php
require_once __DIR__ . '/../common/config.php';

if (isset($_GET['logout'])) {
    unset($_SESSION['aid']);
    session_regenerate_id(true);
    header('Location: login.php');
    exit;
}
if (!empty($_SESSION['aid']) && row('SELECT id FROM admin WHERE id=?', 'i', [(int)$_SESSION['aid']])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    handle(function () {
        $a = row('SELECT * FROM admin WHERE username=?', 's', [p('username')]);
        if (!$a || !password_verify((string)($_POST['password'] ?? ''), $a['password'])) {
            throw new RuntimeException('Wrong username or password.');
        }
        session_regenerate_id(true);
        $_SESSION['aid'] = (int)$a['id'];
        return ['ok' => true, 'redirect' => 'index.php'];
    });
}

$noChrome = true;
$pageTitle = 'Login';
include __DIR__ . '/common/header.php';
?>
<div class="min-h-screen flex flex-col">
  <div class="bg-brand text-white text-center py-10">
    <i class="fa-solid fa-user-shield text-4xl"></i>
    <div class="text-2xl font-bold mt-2"><?= e($appName) ?> Admin</div>
  </div>
  <div class="bg-white flex-1 max-w-md w-full mx-auto p-4">
    <div id="msg" class="hidden mb-3 p-3 text-sm bg-red-100 text-red-700"></div>
    <form id="f" class="space-y-3" onsubmit="send(event)">
      <input type="text" name="username" placeholder="Username" required autocomplete="username" class="w-full bg-gray-100 p-3 text-sm outline-none">
      <input type="password" name="password" placeholder="Password" required autocomplete="current-password" class="w-full bg-gray-100 p-3 text-sm outline-none">
      <button type="submit" class="w-full bg-brand text-white py-3 font-semibold">Login</button>
    </form>
  </div>
</div>
<script>
  async function send(e) {
    e.preventDefault();
    var f = e.target, btn = f.querySelector('button'), box = document.getElementById('msg');
    btn.disabled = true;
    box.classList.add('hidden');
    var r = await api('login.php', new FormData(f));
    if (r.ok) { location.href = r.redirect; return; }
    box.textContent = r.msg || 'Something went wrong.';
    box.classList.remove('hidden');
    btn.disabled = false;
  }
</script>
<?php include __DIR__ . '/common/bottom.php'; ?>
