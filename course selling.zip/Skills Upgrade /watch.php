<?php
require_once __DIR__ . '/common/config.php';

/* ---------- Protected video stream (no direct file URL is ever exposed) ---------- */
if (isset($_GET['stream'])) {
    $vid = row('SELECT v.*, ch.course_id FROM videos v JOIN chapters ch ON ch.id=v.chapter_id WHERE v.id=?', 'i', [(int)$_GET['stream']]);
    if (!$vid) {
        http_response_code(404);
        exit;
    }
    $ok = !empty($_SESSION['aid']) || (!empty($_SESSION['uid']) && owns($_SESSION['uid'], $vid['course_id']));
    if (!$ok) {
        http_response_code(403);
        exit;
    }
    $path = UPLOAD_DIR . '/videos/' . basename($vid['filename']);
    if (!is_file($path)) {
        http_response_code(404);
        exit;
    }
    session_write_close(); // do not block other requests while streaming
    set_time_limit(0);
    while (ob_get_level()) {
        ob_end_clean();
    }
    $size = filesize($path);
    $start = 0;
    $end = $size - 1;
    header('Content-Type: video/mp4');
    header('Accept-Ranges: bytes');
    header('Cache-Control: private, no-store');
    header('Content-Disposition: inline');
    header('X-Content-Type-Options: nosniff');
    if (isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', $_SERVER['HTTP_RANGE'], $m)) {
        if ($m[1] !== '') {
            $start = (int)$m[1];
            if ($m[2] !== '') {
                $end = min((int)$m[2], $size - 1);
            }
        } elseif ($m[2] !== '') {
            $start = max(0, $size - (int)$m[2]);
        }
        if ($start > $end || $start >= $size) {
            http_response_code(416);
            header("Content-Range: bytes */$size");
            exit;
        }
        http_response_code(206);
        header("Content-Range: bytes $start-$end/$size");
    }
    header('Content-Length: ' . ($end - $start + 1));
    $fp = fopen($path, 'rb');
    fseek($fp, $start);
    $left = $end - $start + 1;
    while ($left > 0 && !feof($fp)) {
        $buf = fread($fp, min(131072, $left));
        echo $buf;
        $left -= strlen($buf);
        flush();
        if (connection_aborted()) {
            break;
        }
    }
    fclose($fp);
    exit;
}

/* ---------- Page ---------- */
require_user();
$me = user();
$cid = (int)($_GET['id'] ?? 0);
if (!$cid) {
    header('Location: mycourses.php');
    exit;
}
$course = row('SELECT * FROM courses WHERE id=?', 'i', [$cid]);
if (!$course) {
    header('Location: mycourses.php');
    exit;
}
if (!owns($me['id'], $cid)) { // only purchased courses can be watched
    header('Location: course_detail.php?id=' . $cid);
    exit;
}

$chapters = rows('SELECT * FROM chapters WHERE course_id=? ORDER BY id', 'i', [$cid]);
$vids = rows('SELECT v.* FROM videos v JOIN chapters ch ON ch.id=v.chapter_id WHERE ch.course_id=? ORDER BY v.id', 'i', [$cid]);
$byChapter = [];
foreach ($vids as $v) {
    $byChapter[$v['chapter_id']][] = $v;
}
$flat = [];
foreach ($chapters as $ch) {
    foreach ($byChapter[$ch['id']] ?? [] as $v) {
        $flat[] = ['id' => (int)$v['id'], 'title' => $v['title']];
    }
}
$idx = [];
foreach ($flat as $i => $f) {
    $idx[$f['id']] = $i;
}

$pageTitle = $course['title'];
include __DIR__ . '/common/header.php';
?>
<style>
  #seek{-webkit-appearance:none;appearance:none;height:4px;background:#475569;outline:none;touch-action:none;cursor:pointer}
  #seek::-webkit-slider-thumb{-webkit-appearance:none;width:12px;height:12px;background:#38bdf8}
  #seek::-moz-range-thumb{width:12px;height:12px;background:#38bdf8;border:0;border-radius:0}
  #v{object-fit:contain}
  #pl:fullscreen,#pl:-webkit-full-screen{width:100%;height:100%;aspect-ratio:auto}
</style>

<div id="pl" class="relative bg-black aspect-video w-full">
  <video id="v" class="w-full h-full" playsinline webkit-playsinline preload="metadata"
         controlsList="nodownload noplaybackrate noremoteplayback" disablePictureInPicture disableRemotePlayback></video>
  <div class="absolute top-2 right-2 text-white/30 text-xs pointer-events-none"><?= e($me['email']) ?></div>
  <button type="button" id="big" class="absolute inset-0 m-auto w-16 h-16 bg-black/60 text-white text-2xl flex items-center justify-center" aria-label="Play">
    <i class="fa-solid fa-play"></i>
  </button>
  <div class="absolute bottom-0 inset-x-0 bg-black/70 text-white flex items-center gap-3 px-3 h-11 text-xs">
    <button type="button" id="pp" class="w-6" aria-label="Play or pause"><i class="fa-solid fa-play text-base"></i></button>
    <span id="cur" class="w-9 text-center">0:00</span>
    <input id="seek" type="range" min="0" max="1000" value="0" class="flex-1">
    <span id="dur" class="w-9 text-center">0:00</span>
    <button type="button" id="fs" class="w-6" aria-label="Fullscreen"><i class="fa-solid fa-expand text-base"></i></button>
  </div>
</div>

<div class="bg-white p-4">
  <div id="nowTitle" class="font-bold leading-snug"><?= e($course['title']) ?></div>
  <div class="text-xs text-gray-500 mt-1"><?= count($flat) ?> video<?= count($flat) === 1 ? '' : 's' ?></div>
</div>

<div class="mt-2 pb-4">
  <?php if (!$chapters || !$flat): ?>
    <p class="bg-white p-4 text-sm text-gray-500">Videos for this course are coming soon.</p>
  <?php endif; ?>
  <?php foreach ($chapters as $n => $ch): $list = $byChapter[$ch['id']] ?? []; ?>
    <div class="bg-white mb-2">
      <button type="button" data-ch class="w-full flex items-center justify-between p-4 text-left font-semibold text-sm">
        <span><?= e($ch['title']) ?></span>
        <i class="fa-solid <?= $n === 0 ? 'fa-chevron-up' : 'fa-chevron-down' ?> text-gray-400"></i>
      </button>
      <div class="<?= $n === 0 ? '' : 'hidden' ?>">
        <?php if (!$list): ?>
          <div class="px-4 pb-4 text-sm text-gray-400">No videos in this chapter yet.</div>
        <?php endif; ?>
        <?php foreach ($list as $v): ?>
          <button type="button" data-i="<?= $idx[$v['id']] ?>" class="vitem w-full flex items-center gap-3 px-4 py-3 text-left text-sm bg-gray-50">
            <i class="fa-solid fa-circle-play text-brand text-lg"></i>
            <span class="flex-1"><?= e($v['title']) ?></span>
          </button>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<script>
  var VIDEOS = <?= json_encode($flat, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  var v = document.getElementById('v'), pl = document.getElementById('pl'), big = document.getElementById('big'),
      pp = document.getElementById('pp'), seek = document.getElementById('seek'), cur = document.getElementById('cur'),
      dur = document.getElementById('dur'), fs = document.getElementById('fs'), nowTitle = document.getElementById('nowTitle'),
      items = document.querySelectorAll('.vitem'), now = -1, dragging = false;

  function fmt(s) {
    if (!isFinite(s)) return '0:00';
    s = Math.floor(s);
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
    return (h ? h + ':' + (m < 10 ? '0' : '') : '') + m + ':' + (x < 10 ? '0' : '') + x;
  }
  function paint() {
    var pct = v.duration ? (v.currentTime / v.duration) * 100 : 0;
    seek.style.background = 'linear-gradient(to right,#0ea5e9 ' + pct + '%,#475569 ' + pct + '%)';
  }
  function setIcons() {
    var playing = !v.paused && !v.ended;
    pp.innerHTML = '<i class="fa-solid ' + (playing ? 'fa-pause' : 'fa-play') + ' text-base"></i>';
    big.style.display = playing ? 'none' : 'flex';
  }
  function play(i) {
    if (!VIDEOS[i]) return;
    now = i;
    v.src = 'watch.php?stream=' + VIDEOS[i].id;
    v.load();
    v.play().catch(function () {});
    nowTitle.textContent = VIDEOS[i].title;
    items.forEach(function (b) {
      var on = parseInt(b.dataset.i, 10) === i;
      b.classList.toggle('bg-sky-100', on);
      b.classList.toggle('bg-gray-50', !on);
    });
    window.scrollTo(0, 0);
  }
  function toggle() {
    if (now < 0) { if (VIDEOS.length) play(0); return; }
    if (v.paused) v.play(); else v.pause();
  }

  items.forEach(function (b) { b.addEventListener('click', function () { play(parseInt(b.dataset.i, 10)); }); });
  document.querySelectorAll('[data-ch]').forEach(function (b) {
    b.addEventListener('click', function () {
      var body = b.nextElementSibling, ic = b.querySelector('i');
      body.classList.toggle('hidden');
      ic.className = 'fa-solid ' + (body.classList.contains('hidden') ? 'fa-chevron-down' : 'fa-chevron-up') + ' text-gray-400';
    });
  });

  big.addEventListener('click', toggle);
  pp.addEventListener('click', toggle);
  v.addEventListener('click', toggle);
  v.addEventListener('play', setIcons);
  v.addEventListener('pause', setIcons);
  v.addEventListener('ended', function () { setIcons(); if (now + 1 < VIDEOS.length) play(now + 1); });
  v.addEventListener('loadedmetadata', function () { dur.textContent = fmt(v.duration); });
  v.addEventListener('timeupdate', function () {
    cur.textContent = fmt(v.currentTime);
    if (!dragging && v.duration) seek.value = Math.round((v.currentTime / v.duration) * 1000);
    paint();
  });
  seek.addEventListener('input', function () {
    dragging = true;
    if (v.duration) { v.currentTime = (seek.value / 1000) * v.duration; }
    paint();
  });
  seek.addEventListener('change', function () { dragging = false; });
  fs.addEventListener('click', function () {
    var on = document.fullscreenElement || document.webkitFullscreenElement;
    if (on) { (document.exitFullscreen || document.webkitExitFullscreen).call(document); }
    else if (pl.requestFullscreen) pl.requestFullscreen();
    else if (pl.webkitRequestFullscreen) pl.webkitRequestFullscreen();
    else if (v.webkitEnterFullscreen) v.webkitEnterFullscreen();
  });
  setIcons();
  paint();
</script>
<?php include __DIR__ . '/common/bottom.php'; ?>
