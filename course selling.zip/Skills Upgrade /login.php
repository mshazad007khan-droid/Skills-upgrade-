<?php
require_once __DIR__ . '/common/config.php';
if (user()) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = p('action');
    handle(function () use ($action) {
        if ($action === 'login') {
            $email = strtolower(p('email'));
            $pass = (string)($_POST['password'] ?? '');
            $u = row('SELECT id,password FROM users WHERE email=?', 's', [$email]);
            if (!$u || !password_verify($pass, $u['password'])) {
                throw new RuntimeException('Wrong email or password.');
            }
            session_regenerate_id(true);
            $_SESSION['uid'] = (int)$u['id'];
            return ['ok' => true, 'redirect' => 'index.php'];
        }
        if ($action === 'signup') {
            $name = p('name');
            $phone = preg_replace('/[\s\-]/', '', p('phone'));
            $email = strtolower(p('email'));
            $pass = (string)($_POST['password'] ?? '');
            if (mb_strlen($name) < 2 || mb_strlen($name) > 100) {
                throw new RuntimeException('Enter your full name.');
            }
            if (!preg_match('/^\+?[0-9]{10,15}$/', $phone)) {
                throw new RuntimeException('Enter a valid phone number.');
            }
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new RuntimeException('Enter a valid email address.');
            }
            if (strlen($pass) < 6) {
                throw new RuntimeException('Password must be at least 6 characters.');
            }
            if (row('SELECT id FROM users WHERE email=?', 's', [$email])) {
                throw new RuntimeException('This email is already registered. Please log in.');
            }
            $r = exec_sql('INSERT INTO users (name,phone,email,password) VALUES (?,?,?,?)', 'ssss', [$name, $phone, $email, password_hash($pass, PASSWORD_DEFAULT)]);
            session_regenerate_id(true);
            $_SESSION['uid'] = (int)$r['id'];
            return ['ok' => true, 'redirect' => 'index.php'];
        }
        throw new RuntimeException('Invalid request.');
    });
}

$noChrome = true;
$pageTitle = 'Login';
include __DIR__ . '/common/header.php';
?>
<div class="min-h-screen flex flex-col">
  <div class="bg-brand text-white text-center py-10">
    <i class="fa-solid fa-graduation-cap text-4xl"></i>
    <div class="text-2xl font-bold mt-2"><?= e($appName) ?></div>
    <div class="text-sm text-sky-100 mt-1">Learn new skills, anytime.</div>
  </div>

  <div class="bg-white flex-1 max-w-md w-full mx-auto">
    <div class="grid grid-cols-2">
      <button type="button" id="tabLogin" class="py-4 font-semibold bg-white text-brand" onclick="tab('login')">Login</button>
      <button type="button" id="tabSignup" class="py-4 font-semibold bg-gray-100 text-gray-500" onclick="tab('signup')">Sign up</button>
    </div>

    <div id="msg" class="hidden mx-4 mt-4 p-3 text-sm bg-red-100 text-red-700"></div>

    <form id="loginForm" class="p-4 space-y-3" onsubmit="send(event,'login')">
      <input type="email" name="email" placeholder="Email" required class="w-full bg-gray-100 p-3 text-sm outline-none">
      <input type="password" name="password" placeholder="Password" required class="w-full bg-gray-100 p-3 text-sm outline-none">
      <button type="submit" class="w-full bg-brand text-white py-3 font-semibold">Login</button>
    </form>

    <form id="signupForm" class="hidden p-4 space-y-3" onsubmit="send(event,'signup')">
      <input type="text" name="name" placeholder="Full name" required class="w-full bg-gray-100 p-3 text-sm outline-none">
      <input type="tel" name="phone" placeholder="Phone number" required class="w-full bg-gray-100 p-3 text-sm outline-none">
      <input type="email" name="email" placeholder="Email" required class="w-full bg-gray-100 p-3 text-sm outline-none">
      <input type="password" name="password" placeholder="Password (min 6 characters)" required minlength="6" class="w-full bg-gray-100 p-3 text-sm outline-none">
      <button type="submit" class="w-full bg-brand text-white py-3 font-semibold">Create account</button>
    </form>
  </div>
</div>

<script>
  function tab(t) {
    var login = t === 'login';
    document.getElementById('loginForm').classList.toggle('hidden', !login);
    document.getElementById('signupForm').classList.toggle('hidden', login);
    document.getElementById('tabLogin').className = 'py-4 font-semibold ' + (login ? 'bg-white text-brand' : 'bg-gray-100 text-gray-500');
    document.getElementById('tabSignup').className = 'py-4 font-semibold ' + (login ? 'bg-gray-100 text-gray-500' : 'bg-white text-brand');
    document.getElementById('msg').classList.add('hidden');
  }
  async function send(e, action) {
    e.preventDefault();
    var f = e.target, btn = f.querySelector('button[type=submit]'), box = document.getElementById('msg');
    btn.disabled = true;
    box.classList.add('hidden');
    var fd = new FormData(f);
    fd.append('action', action);
    var r = await api('login.php', fd);
    if (r.ok) { location.href = r.redirect; return; }
    box.textContent = r.msg || 'Something went wrong.';
    box.classList.remove('hidden');
    btn.disabled = false;
  }
</script>
<?php include __DIR__ . '/common/bottom.php'; ?>
