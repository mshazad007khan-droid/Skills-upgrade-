<?php
require_once __DIR__ . '/common/config.php';

if (isset($_GET['logout'])) {
    unset($_SESSION['uid']);
    session_regenerate_id(true);
    header('Location: login.php');
    exit;
}
require_user();
$me = user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    handle(function () use ($me) {
        if (p('action') !== 'update') {
            throw new RuntimeException('Invalid request.');
        }
        $name = p('name');
        $phone = preg_replace('/[\s\-]/', '', p('phone'));
        $email = strtolower(p('email'));
        $new = (string)($_POST['new_password'] ?? '');

        if (mb_strlen($name) < 2 || mb_strlen($name) > 100) {
            throw new RuntimeException('Enter your full name.');
        }
        if (!preg_match('/^\+?[0-9]{10,15}$/', $phone)) {
            throw new RuntimeException('Enter a valid phone number.');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new RuntimeException('Enter a valid email address.');
        }
        if (row('SELECT id FROM users WHERE email=? AND id<>?', 'si', [$email, $me['id']])) {
            throw new RuntimeException('This email is used by another account.');
        }
        if ($new !== '') {
            if (strlen($new) < 6) {
                throw new RuntimeException('New password must be at least 6 characters.');
            }
            $u = row('SELECT password FROM users WHERE id=?', 'i', [$me['id']]);
            if (!password_verify((string)($_POST['current_password'] ?? ''), $u['password'])) {
                throw new RuntimeException('Current password is incorrect.');
            }
            exec_sql('UPDATE users SET password=? WHERE id=?', 'si', [password_hash($new, PASSWORD_DEFAULT), $me['id']]);
        }
        exec_sql('UPDATE users SET name=?, phone=?, email=? WHERE id=?', 'sssi', [$name, $phone, $email, $me['id']]);
        return ['ok' => true, 'msg' => 'Profile updated.'];
    });
}

$pageTitle = 'Profile';
include __DIR__ . '/common/header.php';
?>
<div class="bg-brand text-white text-center py-6">
  <i class="fa-solid fa-circle-user text-6xl"></i>
  <div class="mt-2 font-bold"><?= e($me['name']) ?></div>
</div>

<form id="pf" class="bg-white p-4 space-y-3" onsubmit="save(event)">
  <label class="block text-xs text-gray-500">Name</label>
  <input type="text" name="name" value="<?= e($me['name']) ?>" required class="w-full bg-gray-100 p-3 text-sm outline-none">
  <label class="block text-xs text-gray-500">Email</label>
  <input type="email" name="email" value="<?= e($me['email']) ?>" required class="w-full bg-gray-100 p-3 text-sm outline-none">
  <label class="block text-xs text-gray-500">Phone</label>
  <input type="tel" name="phone" value="<?= e($me['phone']) ?>" required class="w-full bg-gray-100 p-3 text-sm outline-none">

  <div class="pt-2 text-sm font-semibold">Change password <span class="text-gray-400 font-normal">(optional)</span></div>
  <input type="password" name="current_password" placeholder="Current password" class="w-full bg-gray-100 p-3 text-sm outline-none">
  <input type="password" name="new_password" placeholder="New password (min 6 characters)" class="w-full bg-gray-100 p-3 text-sm outline-none">

  <button type="submit" class="w-full bg-brand text-white py-3 font-semibold">Save changes</button>
</form>

<a href="profile.php?logout=1" class="block mx-4 my-4 bg-red-600 text-white text-center py-3 font-semibold">
  <i class="fa-solid fa-right-from-bracket mr-2"></i>Logout
</a>

<script>
  async function save(e) {
    e.preventDefault();
    var f = e.target, btn = f.querySelector('button[type=submit]');
    btn.disabled = true;
    var fd = new FormData(f);
    fd.append('action', 'update');
    var r = await api('profile.php', fd);
    btn.disabled = false;
    if (r.ok) {
      toast(r.msg);
      f.current_password.value = '';
      f.new_password.value = '';
      setTimeout(function () { location.reload(); }, 900);
    } else {
      toast(r.msg || 'Could not save changes.', false);
    }
  }
</script>
<?php include __DIR__ . '/common/bottom.php'; ?>
